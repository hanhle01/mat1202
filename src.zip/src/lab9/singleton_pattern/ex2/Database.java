package lab9.singleton_pattern.ex2;

public class Database {
    private static Database instance;

    private Database() {
        // Khởi tạo kết nối database (giả lập)
        System.out.println("Database connection established.");
    }

    public static Database getInstance() {
        if (instance == null) {
            instance = new Database();
        }
        return instance;
    }

    public void query(String sql) {
        System.out.println("Executing query: " + sql);
    }
}