package lab9.singleton_pattern.ex1;

public class ChocolateBoiler {
    // Biến static lưu trữ instance duy nhất
    private static ChocolateBoiler uniqueInstance;

    private boolean empty;
    private boolean boiled;

    // Constructor private để ngăn tạo instance từ bên ngoài
    private ChocolateBoiler() {
        empty = true;
        boiled = false;
    }

    // Phương thức static trả về instance duy nhất
    public static ChocolateBoiler getInstance() {
        if (uniqueInstance == null) {
            System.out.println("Creating unique instance of Chocolate Boiler");
            uniqueInstance = new ChocolateBoiler();
        }
        System.out.println("Returning instance of Chocolate Boiler");
        return uniqueInstance;
    }

    public void fill() {
        if (isEmpty()) {
            empty = false;
            boiled = false;
            // fill the boiler with a milk/chocolate mixture
            System.out.println("Boiler filled.");
        }
    }

    public void drain() {
        if (!isEmpty() && isBoiled()) {
            // drain the boiled milk and chocolate
            empty = true;
            System.out.println("Boiler drained.");
        }
    }

    public void boil() {
        if (!isEmpty() && !isBoiled()) {
            // bring the contents to a boil
            boiled = true;
            System.out.println("Boiler boiled.");
        }
    }

    public boolean isEmpty() {
        return empty;
    }

    public boolean isBoiled() {
        return boiled;
    }
}
