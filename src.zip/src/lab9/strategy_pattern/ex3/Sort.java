package lab9.strategy_pattern.ex3;

public interface Sort {
    void sort(int[] array);
}