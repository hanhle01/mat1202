package lab9.strategy_pattern.ex2;

class AddStrategy implements ArithmeticStrategy {
    public int execute(int a, int b) {
        return a + b;
    }
}