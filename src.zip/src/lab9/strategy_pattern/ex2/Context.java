package lab9.strategy_pattern.ex2;

class Context {
    private ArithmeticStrategy strategy;

    public void setStrategy(ArithmeticStrategy strategy) {
        this.strategy = strategy;
    }

    public int executeStrategy(int a, int b) {
        return strategy.execute(a, b);
    }
}