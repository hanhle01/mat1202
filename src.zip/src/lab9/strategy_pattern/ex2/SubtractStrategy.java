package lab9.strategy_pattern.ex2;

class SubtractStrategy implements ArithmeticStrategy {
    public int execute(int a, int b) {
        return a - b;
    }
}