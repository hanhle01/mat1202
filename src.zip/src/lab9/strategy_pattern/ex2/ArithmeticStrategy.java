package lab9.strategy_pattern.ex2;

public interface ArithmeticStrategy {
    int execute(int a, int b);
}
