package lab9.strategy_pattern.ex4;

public interface Strategy {
    int execute(int a, int b);
}