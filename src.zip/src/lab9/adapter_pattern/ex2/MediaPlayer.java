package lab9.adapter_pattern.ex2;

public interface MediaPlayer {
    void play(String audioType, String fileName);
}
