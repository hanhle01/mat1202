package lab9.adapter_pattern.ex1;

public class SquarePegAdapter extends RoundPeg {
    private SquarePeg peg;

    public SquarePegAdapter(SquarePeg peg) {
        // Gọi constructor của RoundPeg với radius giả lập
        super(peg.getWidth() * Math.sqrt(2) / 2);
        this.peg = peg;
    }

    public SquarePegAdapter(double radius) {
        super(radius);
    }
}
