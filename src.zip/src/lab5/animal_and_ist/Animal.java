package Lab5_22000090.animal_and_ít;

public class Animal {
    private String name;

    public Animal(String name) {
        this.name = name;
    }
    @Override
    public String toString() {
        return "Animal [name=" + name + "]";
    }
}
