package Lab5_22000090.person_and_its;

public class TestMain {
    public static void main(String[] args) {

    }
}
