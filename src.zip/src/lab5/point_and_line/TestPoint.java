package Lab5_22000090.point_and_line;

public class TestPoint {
    public static void main(String[] args) {
        Point p1 = new Point(10,20);
        System.out.println(p1);
        Point p2 = new Point(100,10);
        System.out.println(p2);
    }
}
