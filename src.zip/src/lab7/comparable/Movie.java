package lab7.comparable;

public class Movie implements Comparable<Movie> {
    private String name;
    private double rating;
    private int year;

    // Dùng để sắp xếp các bộ phim theo năm
    public int compareTo(Movie movie) {
        return Integer.compare(this.year, movie.getYear());
    }

    // Constructor
    public Movie(String name, double rating, int year) {
        this.name = name;
        this.rating = rating;
        this.year = year;
    }

    // Phương thức Getter để truy cập dữ liệu riêng
    public double getRating() {
        return rating;
    }

    public String getName() {
        return name;
    }

    public int getYear() {
        return year;
    }
}
