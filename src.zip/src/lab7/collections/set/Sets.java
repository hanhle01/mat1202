package lab7.collections.set;

import java.util.*;

public class Sets {
    // Hàm trả về giao của hai tập hợp cho trước
    // * (không sử dụng các hàm thư viện)
    public static Set<Integer> intersectionManual(Set<Integer> first, Set<Integer> second) {
        Set<Integer> intersection = new HashSet<>();
        for (Integer i : first) {
            if (second.contains(i)) {
                intersection.add(i);
            }
        }
        return intersection;
    }

    // Hàm trả về hợp của hai tập hợp cho trước
    // * (không sử dụng các hàm thư viện)
    public static Set<Integer> unionManual(Set<Integer> first, Set<Integer> second) {
        Set<Integer> union = new HashSet<>();
        union.addAll(first);
        union.addAll(second);
        return union;

    }

    // Hàm trả về giao của hai tập hợp cho trước (xem retainAll())
    public static Set<Integer> intersection(Set<Integer> first, Set<Integer> second) {
        Set<Integer> intersection = new HashSet<>();
        for (Integer i : first) {
            if (second.contains(i)) {
                intersection.add(i);
            }
        }
        return intersection;
    }

    // Hàm trả về hợp của hai tập hợp cho trước (xem addAll())
    public static Set<Integer> union(Set<Integer> first, Set<Integer> second) {
        Set<Integer> union = new HashSet<>();
        union.addAll(first);
        union.addAll(second);
        return union;
    }

    // Hàm chuyển một tập hợp thành danh sách mà không có phần tử trùng lặp
    // * Lưu ý: các collections có thể được tạo ra từ một collection khác!
    public static List<Integer> toList(Set<Integer> second) {
        return new ArrayList<>(second);
    }

    // Hàm loại bỏ các phần tử trùng lặp trong một danh sách
    // * Lưu ý: các collections có thể được tạo ra từ một collection khác!
    public static List<Integer> removeDuplicates(List<Integer> source) {
        return new ArrayList<>(source);
    }

    // Hàm loại bỏ các phần tử trùng lặp trong một danh sách
    // * mà không sử dụng các kỹ thuật constructor như đã thấy ở trên
    public static List<Integer> removeDuplicatesManual(List<Integer> source) {
        Set<Integer> set = new HashSet<>(source); // Chuyển thành Set để loại bỏ trùng lặp
        return new ArrayList<>(set);
    }

    // Hàm nhận vào một chuỗi và trả về ký tự lặp lại đầu tiên
    // * Ví dụ: firstRecurringCharacter("abaco") -> a.
    public static String firstRecurringCharater(String s) {
        Set<Character> set = new HashSet<>();
        for (char c : s.toCharArray()) {
            if(set.contains(c)) {
                return String.valueOf(c);
            }
            set.add(c);
        }
        return "NO";
    }

    // Hàm nhận vào một chuỗi và trả về một tập hợp chứa tất cả các ký tự lặp lại.
    // * Ví dụ: allRecurringChars("mamma") -> [m, a].
    public static Set<Character> allRecurringChars(String s) {
        Set<Character> fullSet = new HashSet<>();
        Set<Character> set = new HashSet<>();
        for (char c : s.toCharArray()) {
            if(fullSet.contains(c)) {
                set.add(c);
            }
            fullSet.add(c);
        }
        return set;
    }

    // Hàm chuyển một tập hợp thành một mảng
    public static Integer[] toArray(Set<Integer> set) {
        return set.toArray(new Integer[set.size()]);
    }

    // Hàm trả về phần tử đầu tiên từ một TreeSet
    // * Lưu ý: sử dụng các phương thức đặc biệt của TreeSet
    public static int getFirst(TreeSet<Integer> set) {
        return set.first();
    }

    // Hàm trả về phần tử cuối cùng từ một TreeSet
    // * Lưu ý: sử dụng các phương thức đặc biệt của TreeSet
    public static int getLast(TreeSet<Integer> set) {
        return set.last();
    }

    // Hàm lấy phần tử từ một TreeSet
    // * mà lớn hơn một phần tử cho trước.
    // * Lưu ý: sử dụng các phương thức đặc biệt của TreeSet
    public static int getGreater(TreeSet<Integer> set, int value) {
        Integer result = set.higher(value); // Lấy phần tử nhỏ nhất lớn hơn giá trị cho trước
        return result == null ? -1 : result;
    }

    public static void main(String[] args) {
        Set<Integer> set1 = new HashSet<>();
        for (int i = 5; i < 10; i++) {
            set1.add(i);
        }
        set1.add(7);
        System.out.println("Set1: " + set1);
        Set<Integer> set2 = new HashSet<>();
        for (int i = 8; i < 13; i++) {
            set2.add(i);
        }
        System.out.println("Set2: " + set2);

        System.out.println("Giao: " + intersectionManual( set1, set2));
        System.out.println("Hợp: " + unionManual(set1, set2));
        System.out.println("Danh sách không trùng lặp: " + toList(set1));

        List<Integer> list = toList(set1);
        list.add(1);
        list.add(2);
        list.add(1);
        System.out.println("List: " + list);
        System.out.println("List không trùng lặp: " + removeDuplicatesManual(list));
        System.out.println("Ký tu lặp lại đầu tiên là: " + firstRecurringCharater("abaco"));
        System.out.println("Ký tu lặp lại là: " + allRecurringChars("mama"));


        TreeSet<Integer> treeSet = new TreeSet<>();
        treeSet.add(1);
        treeSet.add(2);
        treeSet.add(3);
        System.out.println("TreeSet: " + treeSet);
        System.out.println("Ky tu dau tien cua Treeset la: " + getFirst(treeSet));
        System.out.println("Ky tu cuoi cung cua Treeset la: " + getLast(treeSet));
        System.out.println("Phan tu lon hon 2 la: " + getGreater(treeSet, 2));

    }
}
