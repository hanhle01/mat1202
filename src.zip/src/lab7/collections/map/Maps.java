package lab7.collections.map;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class Maps {
    // Hàm trả về số lượng các cặp khóa-giá trị trong một bản đồ (Map)
    public static int count(Map<Integer, Integer> map) {
        return map.size();
    }

    // Hàm để xóa tất cả các cặp khóa-giá trị trong một bản đồ
    public static void empty(Map<Integer, Integer> map) {
        map.clear();
    }

    // Hàm để kiểm tra xem một bản đồ có chứa một cặp khóa cho trước không
    public static boolean contains(Map<Integer, Integer> map, int key) {
        return map.containsKey(key);
    }

    // Hàm để kiểm tra xem một bản đồ có chứa một cặp khóa cho trước và giá trị của nó có bằng giá trị cho trước không
    public static boolean containsKeyValue(Map<Integer, Integer> map, int key, int value) {
        return map.containsKey(key) && value == map.get(key);
    }

    // Hàm để trả về tập hợp các khóa của một bản đồ
    public static Set<Integer> keySet(Map<Integer, Integer> map) {
        return map.keySet();
    }

    // Hàm để trả về các giá trị của một bản đồ
    public static Collection<Integer> values(Map<Integer, Integer> map) {
        return map.values();
    }

    // Hàm, sử dụng một bản đồ nội bộ, để trả về "black", "white", hoặc "red" tùy thuộc vào giá trị đầu vào.
    // "black" = 0, "white" = 1, "red" = 2
    public static String getColor(int value) {
        if (value == 0) {
            return "black";
        } else if (value == 1) {
            return "white";
        } else if (value == 2) {
            return "red";
        } else {
            return "Unknown"; // Trường hợp không phải 0, 1, hay 2
        }
    }

    public static void main(String[] args) {
        Map<Integer, Integer> map = new HashMap<>();
        map.put(1, 10);
        map.put(2, 20);
        map.put(3, 30);
        map.put(4, 40);
        System.out.println(map);
        System.out.println("So cap khoa trong map la: " + count(map));
        System.out.println("Ban do co chua cap khoa 3 khong: " + contains(map, 3));
        System.out.println("Ban do co chua cap khoa 3 , gia tri 30 khong: " + containsKeyValue(map, 3, 30));
        System.out.println("Tập hợp các khóa của bản đồ: " + keySet(map));
        System.out.println("Tập hợp các giá trị của bản đồ: " + values(map));
        System.out.println("Màu số 2 là: " + getColor(2));

    }
}
