package lab7.collections.list;

import java.util.*;


public class Lists {
    // Chèn 1 phần tử vào đầu danh sách
    public static void inserFirst(List<Integer> list, int value) {
        list.add(0, value);
    }

    // chèn 1 phần tử vào cuối danh sách
    public static void inserLast(List<Integer> list, int value) {
        list.add(list.size(), value);
    }

    // Thay thế phần tử thứ 3 trong danh sách =  giá trị đã cho
    public static void replace(List<Integer> list, int value) {
        list.set(2, value);
    }

    // Hàm để loại bỏ phần tử thứ 3 trong danh sách
    public static void removeThird(List<Integer> list) {
        list.remove(2);
    }

    // Hàm để loại bỏ phần tử có giá trị "666" trong danh sách
    public static void removeEvil(List<Integer> list) {
        list.remove((Integer) 666);
    }

    // Hàm trả về một danh sách chứa 10 số chính phương đầu tiên (ví dụ: 1, 4, 9, 16, ...)
    public static List<Integer> generateSquare() {
        List<Integer> list = new ArrayList<>();
        for (int i = 1; i <= 10; i++) {
            list.add(i*i);
        }
        return list;
    }
    // Hàm để kiểm tra xem danh sách có chứa một giá trị cụ thể không
    public static boolean contains(List<Integer> list, int value) {
        return list.contains(value);
    }

    // Hàm để sao chép một danh sách vào một danh sách khác (không sử dụng các hàm thư viện)
    // Lưu ý: danh sách đích phải được xóa sạch trước khi sao chép
    public static void copy(List<Integer> source, List<Integer> target) {
        target.clear();
        target.addAll(source);
    }

    // Hàm để đảo ngược các phần tử của một danh sách
    public static void reverse (List<Integer> list) {
        Collections.reverse(list);
    }

    // Hàm để đảo ngược các phần tử của một danh sách (không sử dụng các hàm thư viện)
    public static void reverseManual(List<Integer> list) {
        int left = 0;
        int right = list.size() - 1;
        while (left < right) {
            int temp = list.get(left);
            list.set(left, list.get(right));
            list.set(right, temp);
            left++;
            right--;
        }
    }

    // Hàm để chèn cùng một phần tử cả ở đầu và cuối của cùng một danh sách liên kết
    // Lưu ý: bạn có thể sử dụng các phương thức đặc biệt của danh sách liên kết
    public static void insertBeginningEnd(List<Integer> list, int value) {
        list.add(0, value);
        list.add(value);
    }



    public static void main(String[] args) {
        List<Integer> list = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            list.add(i*10);
        }
        List<Integer> list2 = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            list2.add(i*100);
        }
        System.out.println(list);

        inserFirst(list, 1);
        System.out.println(list);

        inserLast(list, 2);
        System.out.println(list);

        replace(list, 3);
        System.out.println(list);

        removeThird(list);
        System.out.println(list);

        removeEvil(list);
        System.out.println(list);

        copy(list2, list);
        System.out.println(list);

        reverse(list);
        System.out.println(list);

        reverseManual(list);
        System.out.println(list);

        insertBeginningEnd(list, 7);
        System.out.println(list);

        System.out.println(generateSquare());
    }
}
