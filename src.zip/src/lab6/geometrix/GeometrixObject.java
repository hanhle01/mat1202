package lab6.geometrix;

public interface GeometrixObject {
    public double getArea();
    public double getPerimeter();
}
