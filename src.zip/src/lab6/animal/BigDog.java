package lab6.animal;

public class BigDog extends Dog {
    public BigDog(String name) {
        super(name);
    }
    @Override
    public void greets() {
        System.out.println("Wooof");
    }
    @Override
    public void greets(Dog another) {
        System.out.println("Woooooof");
    }

    public void greets(BigDog another) {
        System.out.println("Wooooooooof");
    }
}
