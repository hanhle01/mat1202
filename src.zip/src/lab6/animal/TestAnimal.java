package lab6.animal;

public class TestAnimal {
    public static void main(String[] args) {
        Cat cat1 = new Cat("Fluffy");
        Dog dog1 = new Dog("Buddy");
        BigDog bigDog1 = new BigDog("Max");

        cat1.greets();
        dog1.greets();
        bigDog1.greets();

        dog1.greets(new Dog("Charlie"));
        bigDog1.greets(new Dog("Rocky"));
        bigDog1.greets(new BigDog("Bruno"));

        Animal animal1 = new Cat("Whiskers");
        Animal animal2 = new Dog("Spot");
        Animal animal3 = new BigDog("Titan");

        animal1.greets();
        animal2.greets();
        animal3.greets();

        Dog dog2 = (Dog) animal2;
        BigDog bigDog2 = (BigDog) animal3;

        dog2.greets(new Dog("Bailey"));
        bigDog2.greets(new Dog("Cooper"));
        bigDog2.greets(new BigDog("Zeus"));
    }
}
