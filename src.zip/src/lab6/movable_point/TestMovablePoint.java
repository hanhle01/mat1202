package lab6.movable_point;

public class TestMovablePoint {
    public static void main(String[] args) {
        MovablePoint point = new MovablePoint(0, 0, 1, 2);
        System.out.println(point); // Output: (0, 0) speed=(1, 2)

        point.moveRight();
        point.moveDown();
        System.out.println(point); // Output: (1, 2) speed=(1, 2)

        point.moveLeft();
        point.moveUp();
        System.out.println(point); // Output: (0, 0) speed=(1, 2)
    }
}
