package lab6.movable_implementation;

public class TestMovable {
    public static void main(String[] args) {
        Movable m1 = new MovablePoint(5, 6, 10, 15);
        System.out.println(m1);

        m1.moveLeft();
        System.out.println(m1);

        Movable m2 = new MovablePoint(1, 2, 3, 4);
        System.out.println(m2);
        m2.moveRight();
        System.out.println(m2);


        MovableRectangle rect = new MovableRectangle(0, 0, 5, 5, 1, 1);
        System.out.println(rect);

        rect.moveRight();
        rect.moveDown();
        System.out.println(rect);
    }
}
