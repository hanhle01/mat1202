package lab6.resizable_geometrix_object;

public class TestResizableCircle {
    public static void main(String[] args) {
        Circle circle = new Circle(5.0);
        System.out.println(circle);
        System.out.println("Circle Perimeter: " + circle.getPerimeter());
        System.out.println("Circle Area: " + circle.getArea());

        ResizableCircle resizableCircle = new ResizableCircle(10.0);
        System.out.println("Original Radius: " + resizableCircle.radius);
        System.out.println("Original Perimeter: " + resizableCircle.getPerimeter());
        System.out.println("Original Area: " + resizableCircle.getArea());

        resizableCircle.resize(50); // Increase radius by 50%
        System.out.println("Resized Radius: " + resizableCircle.radius);
        System.out.println("Resized Perimeter: " + resizableCircle.getPerimeter());
        System.out.println("Resized Area: " + resizableCircle.getArea());
    }
}
