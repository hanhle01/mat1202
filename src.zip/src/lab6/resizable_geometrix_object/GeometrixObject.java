package lab6.resizable_geometrix_object;

public interface GeometrixObject {
    public double getPerimeter();
    public double getArea();
}
