package lab6.resizable_geometrix_object;

public interface Resizable {
    public double resize(int percent);
}
