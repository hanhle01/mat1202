package lab6.animal_implementation;

public abstract class Animal {
    abstract public void greeting();
}
