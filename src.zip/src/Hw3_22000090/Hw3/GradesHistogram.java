package Hw3_22000090.Hw3;

import java.util.Scanner;

public class GradesHistogram {
    public static void main(String[] args) {
        int[] grades = readGrades();
        System.out.println("Horizontal Histogram:");
        printHorizontalHistogram(grades);
        System.out.println("Vertical Histogram:");
        printVerticalHistogram(grades);
    }

    public static int[] readGrades() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the number of students: ");
        int n = sc.nextInt();
        int[] grades = new int[n];
        for (int i = 0; i < n; i++) {
            System.out.print("Enter the grade for student " + (i + 1) + ": ");
            grades[i] = sc.nextInt();
            if (grades[i] < 0 || grades[i] > 100) {
                System.out.println("Invalid grade. Please enter a value between 0 and 100.");
                i--;
            }
        }
        return grades;
    }

    public static void printHorizontalHistogram(int[] grades) {
        int[] histogram = new int[10];
        for (int grade : grades) {
            int rangeIndex = grade / 10;
            if (rangeIndex == 10) {
                rangeIndex = 9;
            }
            histogram[rangeIndex]++;
        }

        String[] ranges = {" 0-9 ", "10-19", "20-29", "30-39", "40-49", "50-59", "60-69", "70-79", "80-89", "90-100"};
        for (int i = 0; i < 10; i++) {
            System.out.print(ranges[i] + " : ");
            for (int j = 0; j < histogram[i]; j++) {
                System.out.print("*");
            }
            System.out.println();
        }
    }

    public static void printVerticalHistogram(int[] grades) {
        int[] histogram = new int[10];
        for (int grade : grades) {
            int rangeIndex = grade / 10;
            if (rangeIndex == 10) {
                rangeIndex = 9;
            }
            histogram[rangeIndex]++;
        }

        int max = 0;
        for (int i = 0; i < 10; i++) {
            if (histogram[i] > max) {
                max = histogram[i];
            }
        }

        for (int i = max; i > 0; i--) {
            for (int j = 0; j < 10; j++) {
                if (histogram[j] >= i) {
                    System.out.print("   *   ");
                } else {
                    System.out.print("       ");
                }
            }
            System.out.println();
        }

        for (int i = 0; i < 10; i++) {
            System.out.print(" " + (i * 10) + "-" + ((i + 1) * 10 - 1) + " ");
        }
        System.out.println();
    }
}
