package Hw3_22000090.Hw3;

import java.util.Scanner;
import java.util.Arrays;

public class GradesStatistics {
    public static int[] grades;

    public static void main(String[] args) {
        readGrades();
        System.out.println("The grades are: ");
        print(grades);
        System.out.printf("The average is: %.2f\n", average(grades));
        System.out.printf("The median is: %.2f\n", median(grades));
        System.out.println("The minimum is: " + min(grades));
        System.out.println("The maximum is: " + max(grades));
        System.out.printf("The standard deviation is: %.2f\n", standardDeviation(grades));
    }

    public static void readGrades() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the number of students: ");
        int n = sc.nextInt();
        grades = new int[n];

        for (int i = 0; i < n; i++) {
            System.out.print("Enter the grade for student " + (i + 1) + ": ");
            grades[i] = sc.nextInt();
            if (grades[i] < 0 || grades[i] > 100) {
                System.out.println("Invalid grade. Please enter a value between 0 and 100.");
                i--;
            }
        }
    }

    public static void print(int[] array) {
        System.out.print("[");
        for (int i = 0; i < array.length; i++) {
            System.out.print(array[i]);
            if (i < array.length - 1) {
                System.out.print(", ");
            }
        }
        System.out.println("]");
    }

    public static double average(int[] array) {
        int sum = 0;
        for (int grade : array) {
            sum += grade;
        }
        return (double) sum / array.length;
    }

    public static double median(int[] array) {
        Arrays.sort(array);
        int n = array.length;

        if (n % 2 != 0) {
            return array[n / 2];
        } else {
            return (array[(n / 2) - 1] + array[n / 2]) / 2.0;
        }
    }

    public static int max(int[] array) {
        int max = array[0];
        for (int grade : array) {
            if (grade > max) {
                max = grade;
            }
        }
        return max;
    }

    public static int min(int[] array) {
        int min = array[0];
        for (int grade : array) {
            if (grade < min) {
                min = grade;
            }
        }
        return min;
    }

    public static double standardDeviation(int[] array) {
        double mean = average(array);
        double sumSquaredDifferences = 0;
        for (int grade : array) {
            sumSquaredDifferences += Math.pow(grade - mean, 2);
        }
        return Math.sqrt(sumSquaredDifferences / array.length);
    }
}
