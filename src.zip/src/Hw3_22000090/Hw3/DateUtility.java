package Hw3_22000090.Hw3;

public class DateUtility {
    public static String[] strMonths = { "Jan", "Feb", "Mar", "Apr", "May", "Jun",
            "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };
    public static int[] daysInMonths = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

    public static boolean isLeapYear(int year) {
        if (year % 400 == 0) {
            return true;
        } else if (year % 100 == 0) {
            return false;
        } else if (year % 4 == 0) {
            return true;
        }
        return false;
    }

    public static boolean isValidDate(int year, int month, int day) {
        if (year < 1 || year > 9999 || month < 1 || month > 12) {
            return false;
        }
        int daysInMonth = daysInMonths[month - 1];
        if (month == 2 && isLeapYear(year)) {
            daysInMonth = 29;
        }
        return day >= 1 && day <= daysInMonth;
    }

    // Hàm tính toán ngày trong tuần theo công thức Zeller's Congruence
    public static int getDayOfWeek(int year, int month, int day) {
        // Điều chỉnh tháng 1, 2 thành tháng 13, 14 của năm trước
        if (month < 3) {
            month += 12;
            year -= 1;
        }

        // Tính toán các giá trị K (2 chữ số cuối năm) và J (2 chữ số đầu năm)
        int K = year % 100; // Hai chữ số cuối của năm
        int J = year / 100; // Hai chữ số đầu của năm (thế kỷ)

        // Áp dụng công thức Zeller's Congruence
        int h = (day + (13 * (month + 1)) / 5 + K + K / 4 + J / 4 - 2 * J) % 7;

        // Chuyển đổi kết quả sang ngày trong tuần (0 = Saturday, 1 = Sunday, ..., 6 = Friday)
        h = (h + 5) % 7;

        // Trả về ngày trong tuần (0 = Sunday, 1 = Monday, ..., 6 = Saturday)
        return (h + 1) % 7;
    }


    // Chuyển đổi ngày tháng thành chuỗi
    public static String toString(int year, int month, int day) {
        String dayOfWeek = "";
        switch (getDayOfWeek(year, month, day)) {
            case 0: dayOfWeek = "Sunday"; break;
            case 1: dayOfWeek = "Monday"; break;
            case 2: dayOfWeek = "Tuesday"; break;
            case 3: dayOfWeek = "Wednesday"; break;
            case 4: dayOfWeek = "Thursday"; break;
            case 5: dayOfWeek = "Friday"; break;
            case 6: dayOfWeek = "Saturday"; break;
        }
        return dayOfWeek + " " + day + " " + strMonths[month - 1] + " " + year;
    }

    // Hàm main để kiểm tra
    public static void main(String[] args) {
        System.out.println(isLeapYear(1900)); // false
        System.out.println(isLeapYear(2000)); // true
        System.out.println(isLeapYear(2011)); // false
        System.out.println(isLeapYear(2012)); // true

        System.out.println(isValidDate(2012, 2, 29)); // true
        System.out.println(isValidDate(2011, 2, 29)); // false
        System.out.println(isValidDate(2099, 12, 31)); // true
        System.out.println(isValidDate(2099, 12, 32)); // false

        System.out.println(getDayOfWeek(1982, 4, 24)); // 6: Saturday
        System.out.println(getDayOfWeek(2000, 1, 1)); // 6: Saturday
        System.out.println(getDayOfWeek(2054, 6, 19)); // 5: Friday
        System.out.println(getDayOfWeek(2012, 2, 17)); // 5: Friday

        System.out.println(toString(2012, 2, 14)); // Tuesday 14 Feb 2012
    }
}
