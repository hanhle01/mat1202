package Hw3_22000090.Hw2;

import java.util.Scanner;

public class MathLibraryHomework {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        //System.out.print("Enter the x: ");
        double x = Math.PI/4;
        //System.out.print("Enter the numTerms: ");
        int num = 20;
        System.out.println("Sin: " + sinX(x,num));
        System.out.println("Sin: " + Math.sin(x) + " (Math.sin())");
        System.out.println("Cos: " + cosX(x,num));
        System.out.println("Cos: " + Math.cos(x) + " (Math.cos())");

        testSpecialSeries(sc);
        // factorialInt();
        // factorialLong();
        // fibonacciInt();
        //testNumberConversion(sc);
    }

    // 5.1
    public static double sinX(double x, int num) {
        double result = x;
        double term = x;
        for (int i = 1; i < num; i++) {
            term *= (-1) * x*x/(2*i*(2*i+1));
            result += term;
        }
        return result;
    }
    public static double cosX(double x, int num) {
        double result = 1.0;
        double term = 1.0;
        for (int i = 1; i < num; i++) {
            term *= (-1) * x*x/(2*i*(2*i-1));
            result += term;
        }
        return result;
    }

    // 5.2
    public static double specialSeries(double x, int numTerms) {
        double sum = x;
        double term = x;
        for (double i = 1; i <= numTerms; i++) {
            term *= Math.pow(2*1 - 1, 2) * x*x/(2*i*(2*i+1));
            sum += term;
        }
        return sum;
    }

    public static void testSpecialSeries(Scanner sc) {
        double x;
        do {
            System.out.print("Enter the x (-1 <= x <= 1): ");
            x = sc.nextDouble();
        } while (x < -1 || x > 1);
        System.out.print("Enter the numTerms: ");
        int numTerms = sc.nextInt();
        System.out.println("Tổng của dãy số là: " + specialSeries(x, numTerms));
    }

    // 5.3
    // Tính giai thừa và xử lý tràn số cho kiểu int
    public static void factorialInt() {
        long factorial = 1;
        for (int i = 1; i <= 12; i++) {
            factorial *= i;

            if (factorial > Integer.MAX_VALUE) {
                System.out.println("The factorial of " + i + " is out of range");
            } else {
                System.out.println("The factorial of " + i + " is " + factorial);
            }
        }

        if (factorial > Integer.MAX_VALUE) {
            System.out.println("The factorial of 13 is out of range");
        }
    }

    // Tính giai thừa cho kiểu long (64-bit)
    public static void factorialLong() {
        long factorial = 1;
        for (int i = 1; i <= 20; i++) {
            factorial *= i;

            if (factorial > Long.MAX_VALUE) {
                System.out.println("The factorial of " + i + " is out of range");
            } else {
                System.out.println("The factorial of " + i + " is " + factorial);
            }
        }

        if (factorial > Long.MAX_VALUE) {
            System.out.println("The factorial of 21 is out of range");
        }
    }

    // 5.4
    // Tính các số Fibonacci và xử lý tràn số cho kiểu int
    public static void fibonacciInt() {
        int a = 1;  // F(0)
        int b = 1;  // F(1)
        int index = 1;
        System.out.println("F(0) = " + a);
        System.out.println("F(1) = " + b);
        while (true) {
            int nextFib = a + b;
            if (Integer.MAX_VALUE - b < a) {
                System.out.println("F(" + index + ") is out of the range of int");
                break;
            }
            index++;
            System.out.println("F(" + index + ") = " + nextFib);
            a = b;
            b = nextFib;
        }
    }

    // 5.5
    // Chuyển đổi số từ hệ cơ số inRadix sang hệ cơ số outRadix
    public static String toRadix(String in, int inRadix, int outRadix) {
        int decimalValue = Integer.parseInt(in, inRadix);
        return Integer.toString(decimalValue, outRadix).toUpperCase();
    }

    public static void testNumberConversion(Scanner sc) {
        System.out.print("Enter a number and radix: ");
        String inputNumber = sc.next();
        System.out.print("Enter the input radix: ");
        int inputRadix = sc.nextInt();
        System.out.print("Enter the output radix: ");
        int outputRadix = sc.nextInt();
        String result = toRadix(inputNumber, inputRadix, outputRadix);
        System.out.println("\"" + inputNumber + "\" in radix " + inputRadix + " is \"" + result + "\" in radix " + outputRadix + ".");
    }
}
