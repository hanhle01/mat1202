package Hw3_22000090.Hw2;

import java.util.Scanner;

public class DecisionAndLoopsHomework {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        guessNumber(sc);
    }

    public static void guessNumber(Scanner sc) {
        int key = (int)(Math.random()*100);
        int n;
        int dom = 1;
        while(true) {
            System.out.print("Key in your guess: ");
            n = sc.nextInt();
            dom++;
            if(n < key) {
                System.out.println("Try higher");
            } else if(n > key) {
                System.out.println("Try lower");
            } else {
                System.out.println("you got it in " + dom + " trials!");
                break;
            }
        }
    }

    public static void guessWord() {
        Scanner in = new Scanner(System.in);
        System.out.print("Enter the word to be guessed: ");
        String wordToGuess = in.nextLine().toLowerCase();
        guessWord(wordToGuess, in);
    }

    public static void guessWord(String guessedString, Scanner in) {
        boolean[] guessedCorrectly = new boolean[guessedString.length()];
        int trials = 0;
        StringBuilder currentGuess = new StringBuilder("_".repeat(guessedString.length()));

        while (true) {
            trials++;  // Increase trial count
            System.out.print("Enter one character or your guess word: ");
            String playerInput = in.nextLine().toLowerCase();

            if (playerInput.length() == 1) {
                // Single character guess
                char guessedChar = playerInput.charAt(0);
                boolean charFound = false;

                // Check if the guessed character is in the word
                for (int i = 0; i < guessedString.length(); i++) {
                    if (guessedString.charAt(i) == guessedChar && !guessedCorrectly[i]) {
                        guessedCorrectly[i] = true;
                        currentGuess.setCharAt(i, guessedChar);
                        charFound = true;
                    }
                }

                // Print feedback for the trial
                if (charFound) {
                    System.out.println("Trial " + trials + ": " + currentGuess);
                } else {
                    System.out.println("Trial " + trials + ": No match!");
                }
            } else if (playerInput.equals(guessedString)) {
                // Full word guess
                System.out.println("Congratulations! You guessed the word.");
                System.out.println("You got it in " + trials + " trials!");
                break;  // End the game
            } else {
                System.out.println("Trial " + trials + ": No match!");
            }

            // Check if the word is completely guessed
            if (currentGuess.toString().equals(guessedString)) {
                System.out.println("Congratulations! You guessed the word.");
                System.out.println("You got it in " + trials + " trials!");
                break;  // End the game
            }
        }
    }
}
