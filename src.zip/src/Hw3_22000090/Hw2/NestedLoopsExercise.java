package Hw3_22000090.Hw2;

import java.util.Scanner;

public class NestedLoopsExercise {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        squarePattern(inPut(sc));
        checkerPattern(inPut(sc));
        timeTable(inPut(sc));
        triangularPattern(inPut(sc));
        boxPattern(inPut(sc));
        hillPatternX(inPut(sc));
    }

    public static int inPut(Scanner sc) {
        int n;
        do {
            System.out.print("Enter the size: ");
            n = sc.nextInt();
        } while (n <= 0);
        return n;
    }

    // 2.1
    public static void squarePattern(int n) {
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= n; j++) {
                System.out.print("# ");
            }
            System.out.println();
        }
    }

    // 2.2
    public static void checkerPattern(int n) {
        for (int i = 1; i <= n; i++) {
            if(i%2 == 0) {
                System.out.print(" ");
            }
            for (int j = 1; j <= n; j++) {
                System.out.print("# ");
            }
            System.out.println();
        }
    }

    // 2.3
    public static void timeTable(int n) {
        System.out.print(" * |");
        for (int i = 1; i <= n; i++) {
            System.out.printf("%4d",i);
        }
        System.out.println();

        for(int i = 1; i <= n + 1; i++) {
            System.out.print("----");
        }
        System.out.println();

        for (int i = 1; i <= n; i++) {
            System.out.printf("%2d |", i);
            for (int j = 1; j <= n; j++) {
                System.out.printf("%4d", i * j);
            }
            System.out.println();
        }
    }

    // 2.4
    public static void triangularPattern(int n) {
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= 4*n+3; j++) {
                if (i >= j && j <= n) {
                    System.out.print("# ");
                } else if (j >= n+2 && i+j <= 2*n+2) {
                    System.out.print("# ");
                } else if (j >= 2*n+3 && j <= 3*n+2 && j-i >= 2*n+2) {
                    System.out.print("# ");
                } else if(i+j >= 4*n+4) {
                    System.out.print("# ");
                } else {
                    System.out.print("  ");
                }
            }
            System.out.println();
        }
    }

    //2.5
    public static void boxPattern(int n) {
        for (int i = 1; i < n; i++) {
            for (int j = 1; j < 4*n ; j++) {
                if(j==n || j==2*n || j==3*n) {
                    System.out.print("  ");
                }

                if (j<n) {
                    if (i==1 || i==n-1 || j==1 || j==n-1) {
                        System.out.print("# ");
                    } else {
                        System.out.print("  ");
                    }
                }

                if (n < j && j < 2*n) {
                    if (i==1 || i==n-1 || j-i==n) {
                        System.out.print("# ");
                    } else {
                        System.out.print("  ");
                    }
                }

                if (2*n < j && j < 3*n) {
                    if (i==1 || i==n-1 || j+i==3*n) {
                        System.out.print("# ");
                    } else {
                        System.out.print("  ");
                    }
                }

                if (3*n < j) {
                    if (i==1 || i==n-1 || j+i==4*n || j-i==3*n) {
                        System.out.print("# ");
                    } else {
                        System.out.print("  ");
                    }
                }
            }
            System.out.println();
        }
    }

    // 2.6
    public static void hillPatternX(int n) {
        for (int row = 1; row <= 2*n-1; row++) {
            for (int col = 1; col < 8*n; col++) {
                if(col <= 2*n-1) {
                    if (row + col >= n + 1 && row >= col - n + 1 && row <=n) {
                        System.out.print("# ");
                    } else {
                        System.out.print("  ");
                    }
                } else if(2*n <= col && col <= 4*n-1) {
                    if (col - row >= 2*n && row + col <= 4*n && row <= n) {
                        System.out.print("# ");
                    } else {
                        System.out.print("  ");
                    }
                } else if(4*n <= col && col <= 6*n-1) {
                    if (row + col >= 5*n+1 && row + col <= 7*n-1 && col-row <= 5*n-1 && col-row >= 3*n + 1) {
                        System.out.print("# ");
                    } else {
                        System.out.print("  ");
                    }
                } else if(col >= 6*n +1) {
                    if (row + col <= 7*n+1 || row + col > 9*n-2 || col-row > 6*n+3 || col-row < 5*n+2) {
                        System.out.print("# ");
                    } else {
                        System.out.print("  ");
                    }
                } else {
                    System.out.print("  ");
                }
            }
            System.out.println();
        }
    }
}
