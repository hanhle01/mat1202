package Hw3_22000090.Hw2;

import java.util.Scanner;

public class StringAndCharacterHomework {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        testExchangeCipher(sc);
        testPalindromicWord(sc);
        testPalindromicPhrase(sc);

    }

    // 3.1
    public static String exchangeCipher(String inStr) {
        StringBuilder outStr = new StringBuilder();
        inStr = inStr.toUpperCase();

        for (int i = 0; i < inStr.length(); i++) {
            char inChar = inStr.charAt(i);
            if (inChar >= 'A' && inChar <= 'Z') {
                char outChar = (char) ('A' + 'Z' - inChar);
                outStr.append(outChar);
            }
        }
        return outStr.toString();
    }
    public static void testExchangeCipher(Scanner sc) {
        System.out.print("Enter a plaintext string: ");
        String plainText = sc.nextLine();
        String cipherText = exchangeCipher(plainText);
        System.out.println("The ciphertext string is: " + cipherText);
    }

    // 3.2.a
    // Kiểm tra một từ có phải là palindrome không
    public static boolean isPalindromicWord(String inStr) {
        inStr = inStr.toLowerCase();
        int left = 0;
        int right = inStr.length() - 1;

        while (left < right) {
            if (inStr.charAt(left) != inStr.charAt(right)) {
                return false;
            }
            left++;
            right--;
        }
        return true;
    }
    public static void testPalindromicWord(Scanner sc) {
        System.out.print("Enter a word: ");
        String word = sc.nextLine();
        if (isPalindromicWord(word)) {
            System.out.println("\"" + word + "\" is a palindrome.");
        } else {
            System.out.println("\"" + word + "\" is not a palindrome.");
        }
    }

    // 3.2.b
    // Kiểm tra một cụm từ có phải là palindrome không
    public static boolean isPalindromicPhrase(String inStr) {
        inStr = inStr.toLowerCase();
        int left = 0;
        int right = inStr.length() - 1;

        while (left < right) {
            if (!Character.isLetter(inStr.charAt(left))) {
                left++;
            } else if (!Character.isLetter(inStr.charAt(right))) {
                right--;
            } else {
                if (inStr.charAt(left) != inStr.charAt(right)) {
                    return false;
                }
                left++;
                right--;
            }
        }
        return true;
    }
    public static void testPalindromicPhrase(Scanner sc) {
        System.out.print("Enter a phrase: ");
        String phrase = sc.nextLine();
        if (isPalindromicPhrase(phrase)) {
            System.out.println("\"" + phrase + "\" is a palindrome.");
        } else {
            System.out.println("\"" + phrase + "\" is not a palindrome.");
        }
    }
}
