package lab4_22000090.exercisesOnClasses.exercises1_1;

public class TestCircle {
    public static void main(String[] args) {
        Circle circle1 = new Circle();
        System.out.println("Circle 1: " + circle1);
        Circle circle2 = new Circle(2.5);
        System.out.println("Circle 2: " + circle2);
        Circle circle3 = new Circle(3.0, "blue");
        System.out.println("Circle 3: " + circle3);
        circle3.setRadius(5.5);
        circle3.setColor("green");
        System.out.println("Circle 3 after modification: " + circle3);
        System.out.println("Area of Circle 3: " + circle3.getArea());
    }
}
