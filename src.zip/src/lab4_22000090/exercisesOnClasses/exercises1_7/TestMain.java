package lab4_22000090.exercisesOnClasses.exercises1_7;

public class TestMain {
    public static void main(String[] args) {
        MyComplex num1 = new MyComplex(1.1, 2.2);
        MyComplex num2 = new MyComplex(3.3, 4.4);
        System.out.println("Number 1: " + num1);
        System.out.println("Number 2: " + num2);
        System.out.println("Magnitude of num: " + num1.magnitude());
        System.out.println("Argument of num1: " + num1.argument());
        System.out.println("num1 is real? " + num1.isReal());
        System.out.println("num1 is imaginary? " + num1.isImaginary());
        System.out.println("num1 equals num2? " + num1.equals(num2));
        MyComplex sum = num1.addNew(num2);
        System.out.println("Sum: " + sum);

        MyComplex difference = num1.subtractNew(num2);
        System.out.println("Difference: " + difference);

        MyComplex product = num1.multiply(num2);
        System.out.println("Product: " + product);

        MyComplex quotient = num1.divide(num2);
        System.out.println("Quotient: " + quotient);
    }
}
