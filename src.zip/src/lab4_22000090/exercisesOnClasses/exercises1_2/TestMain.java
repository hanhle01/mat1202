package lab4_22000090.exercisesOnClasses.exercises1_2;

public class TestMain {
    public static void main(String[] args) {
        // Kiểm tra các constructor và phương thức toString()
        Circle circle1 = new Circle(1.1);
        System.out.println(circle1); // Gọi phương thức toString()

        Circle circle2 = new Circle(); // Constructor mặc định
        System.out.println(circle2);

        // Kiểm tra phương thức setter và getter
        circle1.setRadius(2.2);
        System.out.println(circle1); // Gọi phương thức toString()
        System.out.println("Radius is: " + circle1.getRadius());

        // Kiểm tra phương thức getArea() và getCircumference()
        System.out.printf("Area is: %.2f%n", circle1.getArea());
        System.out.printf("Circumference is: %.2f%n", circle1.getCircumference());
    }
}
