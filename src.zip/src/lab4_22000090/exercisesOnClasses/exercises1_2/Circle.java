package lab4_22000090.exercisesOnClasses.exercises1_2;

public class Circle {
    // Thuộc tính riêng
    private double radius = 1.0;

    // Constructor mặc định
    public Circle() {
        this.radius = 1.0;
    }

    // Constructor với tham số radius
    public Circle(double radius) {
        this.radius = radius;
    }

    // Phương thức getter để lấy bán kính
    public double getRadius() {
        return this.radius;
    }

    // Phương thức setter để thay đổi bán kính
    public void setRadius(double radius) {
        this.radius = radius;
    }

    // Phương thức tính diện tích hình tròn
    public double getArea() {
        return Math.PI * radius * radius;
    }

    // Phương thức tính chu vi hình tròn
    public double getCircumference() {
        return 2 * Math.PI * radius;
    }

    // Phương thức toString trả về chuỗi mô tả đối tượng Circle
    @Override
    public String toString() {
        return "Circle [radius = " + radius + "]";
    }
}
