package lab4_22000090.exercisesOnComposition.exercises2_8;

public class TestMyCircle {
    public static void main(String[] args) {
        MyCircle circle1 = new MyCircle();
        System.out.println(circle1);
        MyCircle circle2 = new MyCircle(2, 3, 5);
        System.out.println(circle2);
        MyPoint point = new MyPoint(4, 4);
        MyCircle circle3 = new MyCircle(point, 10);
        System.out.println(circle3);

        System.out.println("Center of circle2: " + circle2.getCenter());
        System.out.println("Radius of circle2: " + circle2.getRadius());
        System.out.println("Area of circle3: " + circle3.getArea());
        System.out.println("Circumference of circle3: " + circle3.getCircumference());
        System.out.println("Distance between circle1 and circle2: " + circle1.distance(circle2));
    }
}