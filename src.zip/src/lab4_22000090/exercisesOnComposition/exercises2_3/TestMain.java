package lab4_22000090.exercisesOnComposition.exercises2_3;

public class TestMain {
    public static void main(String[] args) {
        Author author1 = new Author("Tan Ah Teck", "ahteck@nowhere.com");
        System.out.println(author1);  // In thông tin tác giả

        author1.setEmail("ahteck@somewhere.com");
        System.out.println(author1);

        System.out.println("name is: " + author1.getName());
        System.out.println("email is: " + author1.getEmail());

        Book book1 = new Book("12345", "Java for Dummies", author1, 8.8, 88);
        System.out.println(book1);  // In thông tin sách

        book1.setPrice(9.9);
        book1.setQty(99);
        System.out.println(book1);

        System.out.println("isbn is: " + book1.getISBN());
        System.out.println("name is: " + book1.getName());
        System.out.println("price is: " + book1.getPrice());
        System.out.println("qty is: " + book1.getQty());
        System.out.println("author is: " + book1.getAuthor()); // Gọi phương thức toString của Author
        System.out.println("author's name: " + book1.getAuthorName());
        System.out.println("author's name: " + book1.getAuthor().getName());
        System.out.println("author's email: " + book1.getAuthor().getEmail());
    }
}
