package lab4_22000090.exercisesOnComposition.exercises2_7;

public class TestMain {
    public static void main(String[] args) {
        MyPoint point1 = new MyPoint(1, 2);
        MyPoint point2 = new MyPoint(4, 6);
        MyLine line1 = new MyLine(point1, point2);
        System.out.println(line1.toString());
        System.out.println("Length of the line: " + line1.getLength());
        System.out.println("Gradient of the line: " + line1.getGradient());
        line1.setBeginXY(3, 3);
        System.out.println("Modified Line: " + line1.toString());
        line1.setBeginX(5);
        line1.setBeginY(5);
        line1.setEndX(7);
        line1.setEndY(8);
        System.out.println("Updated Line: " + line1.toString());
    }
}
