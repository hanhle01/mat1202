package lab4_22000090.exercisesOnComposition.exercises2_6;

public class TestMyPoint {
    public static void main(String[] args) {
        MyPoint point1 = new MyPoint(3, 4);
        System.out.println("point1: " + point1);
        point1.setX(8);
        point1.setY(6);
        System.out.println("point1 after setting X and Y: " + point1);
        System.out.println("x is: " + point1.getX());
        System.out.println("y is: " + point1.getY());
        point1.setXY(3, 0);
        System.out.println("point1 after setting XY: " + point1);
        int[] coords = point1.getXY();
        System.out.println("x is: " + coords[0]);
        System.out.println("y is: " + coords[1]);
        MyPoint point2 = new MyPoint(0, 4);
        System.out.println("point2: " + point2);
        System.out.println("Distance from point1 to point2: " + point1.distance(point2));
        System.out.println("Distance from point2 to point1: " + point2.distance(point1));
        System.out.println("Distance from point1 to (5, 6): " + point1.distance(5, 6));
        System.out.println("Distance from point1 to origin: " + point1.distance());
    }
}
