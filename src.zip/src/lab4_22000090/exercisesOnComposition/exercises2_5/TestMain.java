package lab4_22000090.exercisesOnComposition.exercises2_5;

public class TestMain {
    public static void main(String[] args) {
        Customer customer1 = new Customer(101, "Tan Ah Teck", 'm');
        System.out.println(customer1);
        Account account1 = new Account(2001, customer1, 1000.0);
        System.out.println(account1);
        account1.deposit(500.0);
        System.out.println(account1);
        account1.withdraw(300.0);
        System.out.println(account1);
        account1.withdraw(2000.0);
        System.out.println(account1);
    }
}
