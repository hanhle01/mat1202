package lab4_22000090.exercisesOnComposition.exercises2_1;

public class TestBook {
    public static void main(String[] args) {
        // Create an Author instance
        Author ahTeck = new Author("Tan Ah Teck", "ahTeck@nowhere.com", 'm');
        System.out.println(ahTeck); // Author's toString()

        // Create a Book instance using the Author
        Book dummyBook = new Book("Java for Dummy", ahTeck, 19.95, 99);
        System.out.println(dummyBook); // Output: Book[name=Java for Dummy, Author[name=Tan Ah Teck, email=ahTeck@nowhere.com, gender=m], price=19.95, qty=99]

        // Test getters and setters
        dummyBook.setPrice(29.95);
        dummyBook.setQty(28);
        System.out.println("Name is: " + dummyBook.getName());
        System.out.println("Price is: " + dummyBook.getPrice());
        System.out.println("Qty is: " + dummyBook.getQty());
        System.out.println("Author is: " + dummyBook.getAuthor());

        System.out.println("Author's name is: " + dummyBook.getAuthor().getName());
        System.out.println("Author's email is: " + dummyBook.getAuthor().getEmail());
        System.out.println("Author's gender is: " + dummyBook.getAuthor().getGender());

        System.out.println("Author's name is: " + dummyBook.getAuthorName());
        System.out.println("Author's email is: " + dummyBook.getAuthorEmail());
        System.out.println("Author's gender is: " + dummyBook.getAuthorGender());

        // Use an anonymous instance of Author to construct another Book
        Book anotherBook = new Book("More Java", new Author("Paul Tan", "paul@somewhere.com", 'm'), 29.95);
        System.out.println(anotherBook);
    }
}
