package lab4_22000090.exercisesOnComposition.exercises2_1;

public class TestAuthor {
    public static void main(String[] args) {
        // Create an Author instance
        Author ahTeck = new Author("Tan Ah Teck", "ahTeck@nowhere.com", 'm');

        // Test the constructor and toString method
        System.out.println(ahTeck); // Output: Author[name=Tan Ah Teck, email=ahTeck@nowhere.com, gender=m]

        // Test the setter and getter methods
        ahTeck.setEmail("paulTan@nowhere.com");
        System.out.println("Name is: " + ahTeck.getName()); // Output: Name is: Tan Ah Teck
        System.out.println("Email is: " + ahTeck.getEmail()); // Output: Email is: paulTan@nowhere.com
        System.out.println("Gender is: " + ahTeck.getGender()); // Output: Gender is: m
    }
}
