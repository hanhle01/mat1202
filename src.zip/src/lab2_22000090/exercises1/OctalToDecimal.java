package lab2_22000090.exercises1;

import java.util.Scanner;

public class OctalToDecimal {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter an Octal string: ");
        String str = sc.nextLine();
        testOctalToDecimal(str);
    }

    public static int octalToDecimal(String str) {
        try {
            return Integer.parseInt(str, 8);
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Invalid Octal string \"" + str + "\"");
        }
    }

    public static void testOctalToDecimal(String str) {
        try {
            int decimal = octalToDecimal(str);
            System.out.println("The equivalent decimal number \"" + str + "\" is: " + decimal);
        } catch (IllegalArgumentException e) {
            System.out.println("error: " + e.getMessage());
        }
    }
}
