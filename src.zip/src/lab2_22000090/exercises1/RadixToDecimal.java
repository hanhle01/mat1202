package lab2_22000090.exercises1;

import java.util.Scanner;

public class RadixToDecimal {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a radix: ");
        int radix = sc.nextInt();
        System.out.print("Enter the string: ");
        String str = sc.next();
        int decimal = radixNToDecimal(str, radix);
        System.out.println("The equivalent decimal number \"" + str + "\" is: " + decimal);

    }
    public static int radixNToDecimal(String radixNStr, int radix) {
        return Integer.parseInt(radixNStr, radix);
    }
}
