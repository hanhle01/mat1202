package lab2_22000090.exercises1;

import java.util.Scanner;

public class ReverseString {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String inStr = sc.nextLine();
        int inStrLen = inStr.length();

        for (int i = inStrLen - 1; i >= 0; --i) {
            System.out.print(inStr.charAt(i));
        }
    }
}
