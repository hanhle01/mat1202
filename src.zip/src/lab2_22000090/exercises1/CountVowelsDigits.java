package lab2_22000090.exercises1;

import java.util.Scanner;

public class CountVowelsDigits {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a String: ");
        String s = sc.nextLine();
        double sLen = s.length();
        int countvowels = 0;
        int  countdigits = 0;
        for (int i = 0; i < sLen; i++) {
            if(s.charAt(i) == 'a' || s.charAt(i) == 'e' || s.charAt(i) == 'i' || s.charAt(i) == 'o' || s.charAt(i) == 'u'  || s.charAt(i) == 'A'  || s.charAt(i) == 'E'  || s.charAt(i) == 'I'  || s.charAt(i) == 'O'  || s.charAt(i) == 'U') {
                countvowels++;
            }
            if(s.charAt(i) == '0' || s.charAt(i) == '1' || s.charAt(i) == '2' || s.charAt(i) == '3' || s.charAt(i) == '4' || s.charAt(i) == '5' || s.charAt(i) == '6' || s.charAt(i) == '7' || s.charAt(i) == '8' || s.charAt(i) == '9') {
                 countdigits++;
            }
        }
        System.out.print("Number of vowels : " + countvowels);
        System.out.println("  (" + ((countvowels/sLen) * 10000.0) / 100.0 + "%" + " )");
        System.out.print("Number of vowels : " + countdigits);
        System.out.println("  (" + ((countdigits/sLen) * 10000.0) / 100.0 + "%" + " )");

    }
}
