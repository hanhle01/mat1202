package lab2_22000090.exercises1;

import java.util.Scanner;

public class CheckHexString {

    public static void main(String[] args) {
        testHexString();
    }

    // Method to verify if a string is a hex string
    public static boolean isHexString(String hexStr) {
        // Check if the string is null or empty
        if (hexStr == null || hexStr.isEmpty()) {
            return false;
        }
        // Regular expression to match hex characters
        String regex = "^[0-9A-Fa-f]+$";
        return hexStr.matches(regex);
    }

    // Method to test the hex string input from user
    public static void testHexString() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a hex string: ");
        String hexStr = scanner.nextLine();

        if (isHexString(hexStr)) {
            System.out.println("\"" + hexStr + "\" is a hex string");
        } else {
            System.out.println("\"" + hexStr + "\" is NOT a hex string");
        }
    }
}
