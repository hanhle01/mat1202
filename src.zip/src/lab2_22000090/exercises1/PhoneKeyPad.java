package lab2_22000090.exercises1;

import java.util.Scanner;

public class PhoneKeyPad {
    public static String phoneKeyPad(String inStr) {
        inStr = inStr.toLowerCase();
        StringBuilder result = new StringBuilder();
        for (char ch : inStr.toCharArray()) {
            if (ch >= 'a' && ch <= 'c') {
                result.append("2");
            } else if (ch >= 'd' && ch <= 'f') {
                result.append("3");
            } else if (ch >= 'g' && ch <= 'i') {
                result.append("4");
            } else if (ch >= 'j' && ch <= 'l') {
                result.append("5");
            } else if (ch >= 'm' && ch <= 'o') {
                result.append("6");
            } else if (ch >= 'p' && ch <= 's') {
                result.append("7");
            } else if (ch >= 't' && ch <= 'v') {
                result.append("8");
            } else if (ch >= 'w' && ch <= 'z') {
                result.append("9");
            }
        }
        return result.toString();
    }

    public static void testPhoneKeyPad() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a string: ");
        String input = sc.next();
        String output = phoneKeyPad(input);
        System.out.println("Keypad digits: " + output);
    }

    public static void main(String[] args) {
        testPhoneKeyPad();
    }
}
