package lab2_22000090.exercises1;

import java.util.Scanner;

public class HexadecimalToDecimal {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a Hexadecimal string: ");
        String str = sc.nextLine();
        testHexadecimalToDecimal(str);
    }

    public static int hexadecimalToDecimal(String hexStr) {
        try {
            return Integer.parseInt(hexStr, 16);
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Invalid hexadecimal string \"" + hexStr + "\"");
        }
    }

    public static void testHexadecimalToDecimal(String hexStr) {
        try {
            int decimal = hexadecimalToDecimal(hexStr);
            System.out.println("The equivalent decimal number for hexadecimal \"" + hexStr + "\" is: " + decimal);
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}