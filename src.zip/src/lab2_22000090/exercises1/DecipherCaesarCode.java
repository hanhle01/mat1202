package lab2_22000090.exercises1;

import java.util.Scanner;

public class DecipherCaesarCode {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a ciphertext string: ");
        String str = sc.nextLine();
        String mau1 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        String mau2 = "abcdefghijklmnopqrstuvwxyz";
        System.out.print("The plaintext string is: ");
        for (int i = 0; i < str.length(); i++) {
            for(int j = 0; j < mau1.length(); j++) {
                if(str.charAt(i) == mau1.charAt(j) || str.charAt(i) == mau2.charAt(j)) {
                    if(j - 3 > 0 ) {
                        System.out.print(mau1.charAt(j - 3));
                    }
                    else {
                        System.out.print(mau1.charAt(j - 3 + 26));
                    }
                }
            }
        }
    }
}