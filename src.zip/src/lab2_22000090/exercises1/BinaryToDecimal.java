package lab2_22000090.exercises1;

import java.util.Scanner;

public class BinaryToDecimal {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a Binary string: ");
        String str = sc.nextLine();
        if(!isBinary(str)) {
            System.out.println("invalid binary string " + str);
        }
        else {
            System.out.println("The equivalent decimal number for binary " + str + " is: " + binaryToDecimal(str));
            System.out.println((toDecimal(str)));
            System.out.println(toBinary(toDecimal(str)));
        }
    }

    public static String toBinary(int decimal) {
        if (decimal == 0) {
            return "0";
        }
        StringBuilder binary = new StringBuilder();
        while (decimal > 0) {
            binary.insert(0, decimal % 2);
            decimal /= 2;
        }
        return binary.toString();
    }

    public static boolean isBinary(String str) {
        for (int i = 0; i < str.length(); i++) {
            if (str.charAt(i) != '0' && str.charAt(i) != '1') {
                return false;
            }
        }
        return true;
    }
    public static int binaryToDecimal(String str) {
        int decimal = 0;
        int base = 1;
        for (int i = str.length() - 1; i >= 0; i--) {
            if (str.charAt(i) == '1') {
                decimal += base;
            }
            base *= 2;
        }
        return decimal;
    }

    public static int toDecimal(String str) {
        int[] arr = new int[str.length()];
        for(int i = 0; i < str.length(); i++) {
            arr[i] = str.charAt(i) - '0';
        }
        int decimal = arr[0];
        for (int i = 1; i < arr.length; i++) {
            decimal = decimal*2 + arr[i];
        }
        return decimal;
    }
}
