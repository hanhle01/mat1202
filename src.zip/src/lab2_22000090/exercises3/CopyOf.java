package lab2_22000090.exercises3;

import java.util.Scanner;

public class CopyOf {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int[] arr = inPut(sc);
        printArray(copyOf(arr));
    }

    public static int[] inPut(Scanner sc) {
        System.out.print("size: ");
        int size = sc.nextInt();
        int[] arr = new int[size];
        System.out.print("Array: ");
        for (int i = 0; i < arr.length; i++) {
            arr[i] = sc.nextInt();
        }
        return arr;
    }

    public static void printArray(int[] arr) {
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + " ");
        }
    }

    public static int[] copyOf(int[] array) {
        if (array == null) {
            return null;
        }
        int[] newArray = new int[array.length];
        for (int i = 0; i < array.length; i++) {
            newArray[i] = array[i];
        }
        return newArray;
    }

}
