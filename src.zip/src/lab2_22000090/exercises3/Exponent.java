package lab2_22000090.exercises3;

import java.util.Scanner;

public class Exponent {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a base: ");
        int base = sc.nextInt();
        System.out.print("Enter a exponent: ");
        int exp = sc.nextInt();
        System.out.println( base + " raises to the power of " + exp + " is: " + exponent(base, exp));
    }

    public static int exponent(int base, int exp) {
        int k = 1;
        for(int i = 1; i <= exp; i++) {
            k *= base;
        }
        return k;
    }
}
