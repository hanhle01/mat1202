package lab2_22000090.exercises3;

import java.util.Scanner;

public class HasEight {
    public static boolean hasEight(int number) {
        while (number > 0) {
            if (number % 10 == 8) {
                return true;
            }
            number /= 10;
        }
        return false;
    }

    public static int testMagicSum(Scanner in) {
        final int SENTINEL = -1;
        int number;
        int magicSum = 0;

        System.out.print("Enter a positive integer (or -1 to end): ");
        number = in.nextInt();

        while (number != SENTINEL) {
            if (hasEight(number)) {
                magicSum += number;
            }

            System.out.print("Enter a positive integer (or -1 to end): ");
            number = in.nextInt();
        }

        return magicSum;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int sum = testMagicSum(scanner);
        System.out.println("The magic sum is: " + sum);
    }
}
