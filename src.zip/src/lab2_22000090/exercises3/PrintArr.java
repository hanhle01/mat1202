package lab2_22000090.exercises3;

public class PrintArr {
    public static void main(String[] args) {
        int[] intArray = {1, 2, 3, 4, 5};
        System.out.print("intArray: ");
        printInt(intArray);

        double[] doubleArray = {1.1, 2.2, 3.3, 4.4, 5.5};
        System.out.print("doubleArray: ");
        printDouble(doubleArray);

        float[] floatArray = {1.1f, 2.2f, 3.3f, 4.4f, 5.5f};
        System.out.print("floatArray: ");
        printFloat(floatArray);
    }

    public static void printInt(int[] array) {
        System.out.print("[");
        for (int i = 0; i < array.length; i++) {
            System.out.print(array[i]);
            if (i < array.length - 1) {
                System.out.print(", ");
            }
        }
        System.out.println("]");
    }

    public static void printDouble(double[] array) {
        System.out.print("[");
        for (int i = 0; i < array.length; i++) {
            System.out.print(array[i]);
            if (i < array.length - 1) {
                System.out.print(", ");
            }
        }
        System.out.println("]");
    }

    public static void printFloat(float[] array) {
        System.out.print("[");
        for (int i = 0; i < array.length; i++) {
            System.out.print(array[i]);
            if (i < array.length - 1) {
                System.out.print(", ");
            }
        }
        System.out.println("]");
    }



}
