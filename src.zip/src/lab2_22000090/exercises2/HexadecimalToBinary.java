package lab2_22000090.exercises2;

import java.util.Scanner;

public class HexadecimalToBinary {
    final static String[] HEX_BITS = {
            "0000", "0001", "0010", "0011",
            "0100", "0101", "0110", "0111",
            "1000", "1001", "1010", "1011",
            "1100", "1101", "1110", "1111"
    };

    public static String hexadecimalToBinary(String hexStr) {
        StringBuilder binaryStr = new StringBuilder();
        hexStr = hexStr.toUpperCase();
        for (char hexChar : hexStr.toCharArray()) {
            if (Character.isDigit(hexChar)) {
                binaryStr.append(HEX_BITS[hexChar - '0'] + " ");
            } else if (hexChar >= 'A' && hexChar <= 'F') {
                binaryStr.append(HEX_BITS[hexChar - 'A' + 10] + " ");
            } else {
                throw new IllegalArgumentException("Invalid hexadecimal character: " + hexChar);
            }
        }

        return binaryStr.toString();
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a hexadecimal string: ");
        String hexStr = sc.nextLine();

        String binaryStr = hexadecimalToBinary(hexStr);
        System.out.println("The equivalent binary for hexadecimal \"" + hexStr + "\" là: " + binaryStr);
    }
}
