package lab2_22000090.exercises2;

import java.util.Scanner;

public class DecimalToHexadecimal {
    public static String decimalToHexadecimal(int positiveInteger) {
        return Integer.toHexString(positiveInteger).toUpperCase();
    }

    public static void testDecimalToHexadecimal() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter a decimal number: ");
        int decimal = scanner.nextInt();

        String hexStr = decimalToHexadecimal(decimal);
        System.out.println("The equivalent hexadecimal number is: " + hexStr);
    }

    public static void main(String[] args) {
        testDecimalToHexadecimal();
    }
}
