package lab1.exercises2;

public class CheckOddEven {
    public static void main(String[] args) {
        int number = 49;
        System.out.println("The number is " + number);

        // in ra "Odd Number" nếu biến kiểu int "number" là số lẻ, hoặc "Even Number" nếu không phải
        if( number % 2 == 0) {
            System.out.println("Even Number");
        }
        else {
            System.out.println("Odd Number");
        }
        System.out.println("Bye!");
    }
}
