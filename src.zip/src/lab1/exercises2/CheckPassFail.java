package lab1.exercises2;

public class CheckPassFail {
    public static void main(String[] args) {
        int mark = 49;
        System.out.println("The mark is " + mark ) ;

        // In ra "PASS" nếu biến kiểu int "mark" có giá trị >= 50; hoặc in ra "FAIL" nếu không phải.
        if(mark >= 50) {
            System.out.println("PASS");
        } else {
            System.out.println("FAIL");
        }
        System.out.println("DONE");     // luôn in ra "DONE" trước khi thoát.
    }

}


