package lab1.exercises3;

public class SumAverageRunningInt {
    public static void main(String[] args) {
        int sum = 0;
        double average;
        final int LOWERBOUND = 1;
        final int UPPERBOUND = 100;

        sum = vongLapFor(LOWERBOUND,UPPERBOUND);
        System.out.println("Sum for: " + sum);

        average = sum/(1 - LOWERBOUND + UPPERBOUND);
        System.out.println("Average: " + average);

        System.out.println("while_do: " + whileDo(LOWERBOUND,UPPERBOUND));
        System.out.println("do_while: " + doWhile(LOWERBOUND,UPPERBOUND));

        sumOfTheSquares(LOWERBOUND,UPPERBOUND);
        sumOddAndEven(LOWERBOUND,UPPERBOUND);
    }

    // for: thích hợp khi biết trước số lần lặp.
    public static int vongLapFor (int LOWERBOUND, int UPPERBOUND){
        int sum = 0;
        for(int number = LOWERBOUND; number <= UPPERBOUND; number++) {
            sum += number;
        }
        return sum;
    }

    // while-do: kiểm tra điều kiện trước khi thực hiện lặp.
    public static int whileDo (int LOWERBOUND, int UPPERBOUND){
        int sum = 0;
        int number = LOWERBOUND;
        while(number <= UPPERBOUND){
            sum += number;
            number++;
        }
        return sum;
    }

    // do-while: luôn thực hiện ít nhất một lần trước khi kiểm tra điều kiện.
    public static int doWhile (int LOWERBOUND, int UPPERBOUND){
        int sum = 0;
        int number = LOWERBOUND;
        do {
            sum += number;
            number++;
        } while(number <= UPPERBOUND);
        return sum;
    }

    // Tổng bình phương: 1² + 2² + 3² + ... + 100²
    public static void sumOfTheSquares (int LOWERBOUND, int UPPERBOUND){
        long sum = 0;
        for(int number = LOWERBOUND; number <= UPPERBOUND; number++) {
            sum += number*number;
        }
        System.out.println("Sum os the squares : " + sum);
    }

    // Tổng các số chẵn và lẻ.
    public static void sumOddAndEven (int LOWERBOUND, int UPPERBOUND){
        int sumOdd = 0;
        int sumEven = 0;
        for (int number = 1; number <= 100; ++number) {
            if (number % 2 == 0) {
                sumEven += number;      // Tổng các số chẵn.
            } else {
                sumOdd += number;       // Tổng các số lẻ.
            }
        }
        int absDiff = Math.abs(sumOdd - sumEven);

        System.out.println("Sum of the odd numbers: " + sumOdd);
        System.out.println("Sum of the even numbers: " + sumEven);
        System.out.println("Difference between the tow sums: " + absDiff);
    }
}
