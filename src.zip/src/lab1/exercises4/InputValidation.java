package lab1.exercises4;

import java.util.Scanner;

public class InputValidation {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int number;

        do {
            System.out.print("Enter a number between 0-10 or 90-100: ");
            number = scanner.nextInt();

            if ((number >= 0 && number <= 10) || (number >= 90 && number <= 100)) {
                break;
            } else {
                System.out.println("Invalid input, try again...");
            }
        } while (true);

        System.out.println("You have entered: " + number);
    }
}
