package lab1.exercises4;

import java.util.Scanner;

public class PensionContributionCalculator {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter the monthly salary: $");    // Nhập lương nhân viên
        double salary = sc.nextDouble();

        System.out.print("Enter the age: ");    // Nhập tuổi nhân viên
        int age = sc.nextInt();

        if (salary > 6000) {
            salary = 6000;
        }

        double employeeRate = 0;
        double employerRate = 0;

        if (age <= 55) {
            employeeRate = 20;
            employerRate = 17;
        } else if (age <= 60) {
            employeeRate = 13;
            employerRate = 13;
        } else if (age <= 65) {
            employeeRate = 7.5;
            employerRate = 9;
        } else {
            employeeRate = 5;
            employerRate = 7.5;
        }

        double employeeContribution = (employeeRate / 100) * salary;    // Mức đóng của người lao động
        double employerContribution = (employerRate / 100) * salary;    // Mức đóng của người sử dụng lao động
        double totalContribution = employeeContribution + employerContribution;

        System.out.printf("The employee's contribution is: $%.2f%n", employeeContribution);
        System.out.printf("The employer's contribution is: $%.2f%n", employerContribution);
        System.out.printf("The total contribution is: $%.2f%n", totalContribution);

    }
}
