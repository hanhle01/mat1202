package lab1.exercises4;

import java.util.Scanner;

public class CircleComputation {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Circle: ");
        double radius = sc.nextDouble();
        double diameter = 2 * radius;   // Đường kính
        double area = Math.PI * radius * radius;    // Diện tích
        double perimeter = 2 * Math.PI * radius;    // Chu vi
        System.out.println("Diameter of circle: " + diameter);
        System.out.println("Area of circle: " + area);
        System.out.println("Perimeter of circle: " + perimeter);

    }
}
