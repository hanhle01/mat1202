package lab1.exercises4;

import java.util.Scanner;

public class SumProductMinMax3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Nhap n: ");
        int n = sc.nextInt();
        int [] arr = new int[n];
        System.out.print("Nhap " + n + " so: ");
        for (int i = 0; i < n; i++) {
            arr[i] = sc.nextInt();
        }

        System.out.println("Sum: " + sumNum(arr));

        System.out.println("Product: " + productNum(arr));

        System.out.println("Min: " + minNum(arr));

        System.out.println("Max: " + maxNum(arr));

    }

    // Tổng các số trong mảng
    public static int sumNum(int[] a) {
        int sum = 0;
        for ( int i = 0; i < a.length; i ++) {
            sum += a[i];
        }
        return sum;
    }

    // Tìm số lớn nhất
    public static int maxNum (int[] a) {
        int max = a[0];
        for (int i = 1; i < a.length; i++) {
            if (max < a[i]) {
                max = a[i];
            }
        }
        return max;
    }

    // Tìm số nhỏ nhất
    public static int minNum (int[] a) {
        int min = a[0];
        for (int i = 1; i < a.length; i++) {
            if (min > a[i]) {
                min = a[i];
            }
        }
        return min;
    }

    // Tính tích các tố trong mảng.
    public static int productNum(int[] a) {
        int product = a[0];
        for (int i = 1; i < a.length; i++) {
            product *= a[i];
        }
        return product;
    }
}
