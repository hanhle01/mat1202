package lab1.exercises4;

import java.util.Scanner;

public class PensionContributionCalculatorWithSentinel {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.print("Enter the monthly salary (or -1 to end): $");
            double salary = sc.nextDouble();

            if (salary == -1) {
                System.out.println("Bye!");
                break;
            }

            System.out.print("Enter the age: ");
            int age = sc.nextInt();

            if (salary > 6000) {
                salary = 6000;
            }

            double employeeRate = 0;
            double employerRate = 0;

            if (age <= 55) {
                employeeRate = 20;
                employerRate = 17;
            } else if (age <= 60) {
                employeeRate = 13;
                employerRate = 13;
            } else if (age <= 65) {
                employeeRate = 7.5;
                employerRate = 9;
            } else {
                employeeRate = 5;
                employerRate = 7.5;
            }

            double employeeContribution = (employeeRate / 100) * salary;
            double employerContribution = (employerRate / 100) * salary;
            double totalContribution = employeeContribution + employerContribution;

            System.out.printf("The employee's contribution is: $%.2f%n", employeeContribution);
            System.out.printf("The employer's contribution is: $%.2f%n", employerContribution);
            System.out.printf("The total contribution is: $%.2f%n", totalContribution);
            System.out.println();
        }
    }
}
