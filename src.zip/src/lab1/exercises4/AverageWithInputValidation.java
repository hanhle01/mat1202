package lab1.exercises4;

import java.util.Scanner;

public class AverageWithInputValidation {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int mark1, mark2, mark3;
        mark1 = getValidMark(scanner, 1);
        mark2 = getValidMark(scanner, 2);

        mark3 = getValidMark(scanner, 3);

        double average = (mark1 + mark2 + mark3) / 3.0;

        System.out.printf("The average is: %.2f%n", average);
    }

    public static int getValidMark(Scanner scanner, int studentNumber) {
        int mark;
        while (true) {
            System.out.print("Enter the mark (0−100) for student " + studentNumber + ": ");
            mark = scanner.nextInt();

            if (mark >= 0 && mark <= 100) {
                break;
            } else {
                System.out.println("Invalid input, try again...");
            }
        }
        return mark;
    }
}
