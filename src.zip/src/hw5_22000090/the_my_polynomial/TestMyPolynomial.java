package hw5_22000090.the_my_polynomial;

public class TestMyPolynomial {
    public static void main(String[] args) {
        MyPolynomial poly1 = new MyPolynomial(1, 2, 3, 0);
        MyPolynomial poly2 = new MyPolynomial(-1, 3, 1);

        System.out.println("Polynomial 1: " + poly1);
        System.out.println("Polynomial 2: " + poly2);

        System.out.println("Degree of Polynomial 1: " + poly1.getDegree());
        System.out.println("Degree of Polynomial 2: " + poly2.getDegree());

        double x = 2.0;
        System.out.println("Evaluate Polynomial 1 at x = " + x + ": " + poly1.evaluate(x));
        System.out.println("Evaluate Polynomial 2 at x = " + x + ": " + poly2.evaluate(x));

        MyPolynomial sum = poly1.add(poly2);
        System.out.println("Sum of Polynomial 1 and Polynomial 2: " + sum);

        MyPolynomial product = poly1.multiply(poly2);
        System.out.println("Product of Polynomial 1 and Polynomial 2: " + product);
    }
}