package hw5_22000090.the_my_complex;

public class MyComplex {
    private double real = 0.0;
    private double imag = 0.0;
    public MyComplex() {}
    public MyComplex(double real, double imag) {
        this.real = real;
        this.imag = imag;
    }
    public double getImag() {
        return imag;
    }
    public void setImag(double imag) {
        this.imag = imag;
    }
    public double getReal() {
        return real;
    }
    public void setReal(double real) {
        this.real = real;
    }
    public void setValue(double real, double imag) {
        this.real = real;
        this.imag = imag;
    }

    public String toString() {
        if (imag > 0) {
            return "(" + real + " + " + imag + "i)";
        } else {
            return "(" + real + " - " + Math.abs(imag) + "i)";
        }
    }
    public boolean isReal() {
        return imag == 0.0;
    }
    public boolean isImaginary() {
        return real == 0.0;
    }
    public boolean equals(double real, double imag) {
        return this.real - real < 1e-8 && this.imag - imag < 1e-8;
    }
    public boolean equals(MyComplex another) {
        return this.real - another.real < 1e-8 && this.imag - another.imag < 1e-8;
    }
    public double magnitude() {
        return Math.sqrt(real * real + imag * imag);
    }
    public double argument() {
        return Math.atan2(imag, real);
    }
    public MyComplex addInto(MyComplex right) {
        this.real += right.real;
        this.imag += right.imag;
        return this;
    }
    public MyComplex addNew(MyComplex right) {
        return new MyComplex(real + right.real, imag + right.imag);
    }
    public MyComplex subtract(MyComplex right) {
        this.real -= right.real;
        this.imag -= right.imag;
        return this;
    }
    public MyComplex subtractNew(MyComplex right) {
        return new MyComplex(real - right.real, imag - right.imag);
    }
    public MyComplex multiply(MyComplex right) {
        this.real  = real * right.real - imag * right.imag;
        this.imag = real * right.imag + imag * right.real;
        return this;
    }
    public MyComplex divide(MyComplex right) {
        this.real  = (real * right.real + imag * right.imag) / (right.real*right.real + right.imag*right.imag);
        this.imag  = (- real * right.imag + imag * right.real) / (right.real*right.real + right.imag*right.imag);
        return this;
    }
    public MyComplex conjugate() {
        return new MyComplex(real, -imag);
    }

}
