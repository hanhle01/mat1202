package hw5_22000090.the_my_date;

public class MyDate {
    private int year;
    private int month;
    private int day;

    public String[] MONTHS = {"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};

    public String[] DAYS = {"Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"};

    public int[] DAYSINMONTHS = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

    public boolean isLeapYear(int year) {
        return (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);
    }

    public boolean isValidDate (int year, int month, int day) {
        if (year < 1 || year > 9999 || month < 1 || month > 12) {
            return false;
        }
        int maxDay = DAYSINMONTHS[month - 1];
        if (month == 2 && isLeapYear(year)) {
            maxDay = 29;
        }
        return day >= 1 && day <= maxDay;
    }

    public static int isDayofWeek(int year, int month, int day) {
        if (month < 3) {
            month += 12;
            year -= 1;
        }
        int K = year % 100;
        int J = year / 100;
        int h = (day + (13 * (month + 1)) / 5 + K + K / 4 + J / 4 - 2 * J) % 7;
        h = (h + 5) % 7;
        return (h + 1) % 7;
    }

    public MyDate(int year, int month, int day) {
        this.year = year;
        this.month = month;
        this.day = day;
    }

    public void setDate(int year, int month, int day) {
        if (!isValidDate(year, month, day)) {
            throw new IllegalArgumentException("Invalid year, month, or day!");
        }
        this.year = year;
        this.month = month;
        this.day = day;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        if (year < 1 || year > 9999) {
            throw new IllegalArgumentException("Invalid year!");
        }
        this.year = year;
    }

    public int getMonth() {
        return month;
    }

    public void setMonth(int month) {
        if (month < 1 || month > 12) {
            throw new IllegalArgumentException("Invalid month!");
        }
        this.month = month;
    }

    public int getDay() {
        return day;
    }

    public void setDay(int day) {
        int maxDay = DAYSINMONTHS[month - 1];
        if (month == 2 && isLeapYear(year)) {
            maxDay = 29;
        }
        if (day < 1 || day > maxDay) {
            throw new IllegalArgumentException("Invalid day!");
        }
        this.day = day;
    }

    public String toString() {
        return "\"" + DAYS[isDayofWeek(year, month, day)] + " " + day + " " + MONTHS[month - 1] + " " + year + "\"";
    }

    public MyDate nextDay() {
        int maxDay = DAYSINMONTHS[month - 1];
        if (month == 2 && isLeapYear(year)) {
            maxDay = 29;
        }
        day++;
        if (day > maxDay) {
            day = 1;
            month++;
            if (month > 12) {
                month = 1;
                year++;
            }
        }
        return this;
    }

    public MyDate nextMonth() {
        int nextMonth = month + 1;
        if (nextMonth > 12) {
            nextMonth = 1;
            year++;
        }
        int maxDay = DAYSINMONTHS[nextMonth - 1];
        if (nextMonth == 2 && isLeapYear(year)) {
            maxDay = 29;
        }
        if (day > maxDay) {
            day = maxDay;
        }
        month = nextMonth;
        return this;
    }

    public MyDate nextYear() {
        if (year >= 9999) {
            throw new IllegalStateException("Year out of range!");
        }
        if (month == 2 && day == 29 && !isLeapYear(year + 1)) {
            day = 28;
        }
        year++;
        return this;
    }

    public MyDate previousDay() {
        day--;
        if (day < 1) {
            month--;
            if (month < 1) {
                month = 12;
                year--;
            }
            day = DAYSINMONTHS[month - 1];
            if (month == 2 && isLeapYear(year)) {
                day = 29;
            }
        }
        return this;
    }

    public MyDate previousMonth() {
        int prevMonth = month - 1;
        if (prevMonth < 1) {
            prevMonth = 12;
            year--;
        }
        int maxDay = DAYSINMONTHS[prevMonth - 1];
        if (prevMonth == 2 && isLeapYear(year)) {
            maxDay = 29;
        }
        if (day > maxDay) {
            day = maxDay;
        }
        month = prevMonth;
        return this;
    }

    public MyDate previousYear() {
        if (month == 2 && day == 29 && !isLeapYear(year - 1)) {
            day = 28;
        }
        year--;
        return this;
    }
}
