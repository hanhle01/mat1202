package hw5_22000090.the_my_time;

public class MyTime {
    private int hour = 0;
    private int minute = 0;
    private int second = 0;
    public MyTime() {}
    public MyTime(int hour, int minute, int second) {
        this.hour = hour;
        this.minute = minute;
        this.second = second;
    }
    public int getMinute() {
        return minute;
    }
    public void setMinute(int minute) {
        this.minute = minute;
    }
    public int getHour() {
        return hour;
    }
    public void setHour(int hour) {
        this.hour = hour;
    }
    public int getSecond() {
        return second;
    }
    public void setSecond(int second) {
        this.second = second;
    }

    public String toString() {
        return "\"" + hour + ":" + minute + ":" + second + "\"";
    }

    public MyTime nextSecond() {
        MyTime newTime = new MyTime(this.getHour(), this.getMinute(), this.getSecond());
        if(newTime.second == 59) {
            newTime.second = 0;
            if(newTime.minute == 59) {
                newTime.minute = 0;
                if(newTime.hour == 23) {
                    newTime.hour = 0;
                } else {
                    newTime.hour++;
                }
            } else {
                newTime.minute++;
            }
        } else {
            newTime.second++;
        }
        return newTime;
    }
    public MyTime nextMinute() {
        MyTime newTime = new MyTime(this.getHour(), this.getMinute(), this.getSecond());
        if(newTime.minute == 59) {
            newTime.minute = 0;
            if(newTime.hour == 23) {
                newTime.hour = 0;
            } else {
                newTime.hour++;
            }
        } else {
            newTime.minute++;
        }
        return newTime;
    }
    public MyTime nextHour() {
        MyTime newTime = new MyTime(this.getHour(), this.getMinute(), this.getSecond());
        if(newTime.hour == 23) {
            newTime.hour = 0;
        }else {
            newTime.hour++;
        }
        return newTime;
    }
    public MyTime previousSecond() {
        MyTime newTime = new MyTime(this.getHour(), this.getMinute(), this.getSecond());
        if(newTime.second == 0) {
            newTime.second = 59;
            if(newTime.minute == 0) {
                newTime.minute = 59;
                if(newTime.hour == 0) {
                    newTime.hour = 23;
                } else {
                    newTime.hour--;
                }
            } else {
                newTime.minute--;
            }
        } else {
            newTime.second--;
        }
        return newTime;
    }
    public MyTime previousMinute() {
        MyTime newTime = new MyTime(this.getHour(), this.getMinute(), this.getSecond());
        if(newTime.minute == 0) {
            newTime.minute = 59;
            if(newTime.hour == 0) {
                newTime.hour = 23;
            } else {
                newTime.hour--;
            }
        } else {
            newTime.minute--;
        }
        return newTime;
    }
    public MyTime previousHour() {
        MyTime newTime = new MyTime(this.getHour(), this.getMinute(), this.getSecond());
        if(newTime.hour == 0) {
            newTime.hour = 23;
        } else {
            newTime.hour--;
        }
        return newTime;
    }
}
