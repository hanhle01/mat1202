package hw5_22000090.the_my_time;

public class TestMyTime {
    public static void main(String[] args) {
        MyTime myTime = new MyTime(23, 59, 59);
        System.out.println("MyTime: " + myTime.toString());
        System.out.println("Next second: " + myTime.nextSecond());
        System.out.println("Next minute: " + myTime.nextMinute());
        System.out.println("Next hour: " + myTime.nextHour());
        System.out.println("Previous second: " + myTime.previousSecond());
        System.out.println("Previous minute: " + myTime.previousMinute());
        System.out.println("Previous hour: " + myTime.previousHour());
    }
}
