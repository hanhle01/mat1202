package lab3_22000090.exercises2;

import java.util.Scanner;

public class RecursiveBinarySearch {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the size of the array: ");
        int size = sc.nextInt();
        int[] arr = new int[size];
        System.out.println("Enter the elements of the array: ");
        for (int i = 0; i < size; i++) {
            arr[i] = sc.nextInt();
        }
        System.out.println("Enter the element to be searched: ");
        int key = sc.nextInt();
        int low = 0;
        int high = arr.length - 1;
        System.out.println("Enter the elements of the array: " + (binarySearch(arr, key, low, high) + 1));
    }

    public static int binarySearch(int[] arr, int key, int low, int high) {
        if(low >= high) {
            return -1;
        }
        int mid = (low + high) / 2;
        if(arr[mid] == key) {
            return mid;
        }
        if(arr[mid] > key) {
            return binarySearch(arr, key, low, mid - 1);
        } else {
            return binarySearch(arr, key, mid + 1, high);
        }
    }
}
