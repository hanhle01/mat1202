package lab3_22000090.exercises1;

import java.util.Scanner;

public class LengthOfARunningNumberSequence {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a number: ");
        int n;
        do {
            n = sc.nextInt();
        } while ( n < 1);
        System.out.print("S(" + n + ") = ");
        for(int i = 1; i <= n; i++) {
            System.out.print(i);
        }
        System.out.println();
        System.out.print("Length is " + len(n));
    }
    public static int len(int n) {
        if (n < 2) {
            return 1;
        } else {
            return len(n - 1) + numOfDigits(n);
        }
    }
    public static int numOfDigits(int n) {
        return Integer.toString(n).length();
    }
}
