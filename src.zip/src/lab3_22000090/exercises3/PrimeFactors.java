package lab3_22000090.exercises3;

import java.util.Scanner;

public class PrimeFactors {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the upper bound: ");
        int n = sc.nextInt();
        primeFactors(n);
    }

    public static void primeFactors(int n) {
        int count = 0;
        System.out.println("These numbers are equal to the product of prime factors: ");
        for(int i = 2; i <= n; i++) {
            if(isProductOfPrimeFactors(i)) {
                System.out.print(i + " ");
                count++;
            }
        }
        System.out.println();
        System.out.println("[" + count + "  numbers found (" + String.format("%.2f", (100.00 * count / n)) + "%)]");
    }

    public static boolean isProductOfPrimeFactors(int n) {
        if(isPrime(n)) {
            return false;
        }

        int originalNum = n;
        int product = 1;

        for (int i = 2; i <= n/i ; i++) {
            if(isPrime(i) && n % i == 0) {
                product *= i;
                while ( n % i == 0) {
                    n /= i;
                }
            }
        }

        if(n > 1 && isPrime(n)) {
            product *= n;
        }
        return product == originalNum;
    }

    public static boolean isPrime(int num) {
        if(num < 2) {
            return false;
        }
        for (int i = 2; i <= Math.sqrt(num); i++) {
            if (num % i == 0) {
                return false;
            }
        }
        return true;
    }
}
