package lab3_22000090.exercises3;

import java.util.Scanner;

public class PrimeNumbers {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Please enter the upper bound: ");
        int num = sc.nextInt();
        prPrime(num);
    }

    public static void prPrime(int num) {
        int dem = 0;
        for(int i = 2; i < num; i++) {
            if(isPrime(i)) {
                System.out.print(i + " ");
                dem++;
            }
        }
        System.out.println();
        System.out.println("[" + dem + " perfect numbers found (" + String.format("%.2f", (100.00 * dem / num)) + "%)]");
    }

    public static boolean isPrime(int num) {
        if(num < 2) {
            return false;
        }
        for (int i = 2; i <= Math.sqrt(num); i++) {
            if (num % i == 0) {
                return false;
            }
        }
        return true;
    }
}
