package lab3_22000090.exercises3;

import java.util.Scanner;
import java.util.ArrayList;

public class PerfectAndDeficientNumbers {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the upper bound : ");
        int n = sc.nextInt();

        ArrayList<Integer> perfectNumbers = new ArrayList<>();
        ArrayList<Integer> deficientNumbers = new ArrayList<>();
        ArrayList<Integer> neither = new ArrayList<>();

        for (int i = 1; i <= n; i++) {
            if (isPerfect(i)) {
                perfectNumbers.add(i);
            } else if (isDeficient(i)) {
                deficientNumbers.add(i);
            } else {
                neither.add(i);
            }
        }
        System.out.println("These numbers are perfect: ");
        for (int num : perfectNumbers) {
            System.out.print(num + " ");
        }
        System.out.println();
        System.out.println("[" + perfectNumbers.size() + " perfect numbers found (" + String.format("%.2f", (100.00 * perfectNumbers.size()) / n) + "%)]");

        System.out.println();
        System.out.println("These numbers are neither dificient nor perfect");
        for (int num : neither) {
            System.out.print(num + " ");
        }
        System.out.println();
        System.out.println("[" + neither.size() + " number found ("
                + String.format("%.2f", (100.00 * neither.size()) / n) + "%)]");
    }

    public static boolean isPerfect(int n) {
        int sum = 0;
        for(int i = 1; i <= n/2; i++) {
            if(n % i == 0) {
                sum += i;
            }
        }
        return sum == n;
    }

    public static boolean isDeficient(int n) {
        int sum = 0;
        for(int i = 1; i <= n/2; i++) {
            if(n % i == 0) {
                sum += i;
            }
        }
        return sum < n;
    }
}
