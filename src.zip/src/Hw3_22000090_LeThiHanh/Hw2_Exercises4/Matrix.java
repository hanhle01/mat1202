package Hw3_22000090_LeThiHanh.Hw2_Exercises4;

import java.util.Scanner;

public class Matrix {
    public static void add(int[][]a, int[][] b) {
        int[][] c = new int[a.length][a[0].length];
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[i].length; j++) {
                c[i][j] = a[i][j] + b[i][j];
            }
        }
        printMatrix(c);
    }

    public static void subtract(int[][]a, int[][] b) {
        int[][] c = new int[a.length][a[0].length];
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[i].length; j++) {
                c[i][j] = a[i][j] - b[i][j];
            }
        }
        printMatrix(c);
    }

    public static void multiply(int[][]a, int[][] b) {
        int[][] c = new int[a.length][a[0].length];
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[i].length; j++) {
                for (int k = 0; k < a[i].length; k++) {
                    c[i][k] += a[i][j] * b[j][k];
                }
            }
        }
        printMatrix(c);
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n;
        do {
            System.out.print("Enter the size: ");
            n = sc.nextInt();
        } while (n <= 0);
        int[][] mat1 = inPutMatrix(n);
        int[][] mat2 = inPutMatrix(n);
        printMatrix(mat1);
        printMatrix(mat2);
        add(mat1, mat2);
        subtract(mat1, mat2);
        multiply(mat1, mat2);
    }

    public static int[][] inPutMatrix(int n) {
        int[][] mat = new int[n][n];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                mat[i][j] = (int) (Math.random() * 10);
            }
        }
        return mat;
    }

    public static void printMatrix(int[][] mat) {
        for (int i = 0; i < mat.length; i++) {
            for (int j = 0; j < mat[i].length; j++) {
                System.out.print(mat[i][j] + " ");
            }
            System.out.println();
        }
        System.out.println();
    }
}
