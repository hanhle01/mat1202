package Hw3_22000090_LeThiHanh.Hw2_Exercises1;

import java.util.Scanner;

public class NumberGuess {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        guessNumber(sc);
    }

    public static void guessNumber(Scanner sc) {
        int key = (int)(Math.random()*100);
        int n;
        int dom = 1;
        while(true) {
            System.out.print("Key in your guess: ");
            n = sc.nextInt();
            dom++;
            if(n < key) {
                System.out.println("Try higher");
            } else if(n > key) {
                System.out.println("Try lower");
            } else {
                System.out.println("you got it in " + dom + " trials!");
                break;
            }
        }
    }

}
