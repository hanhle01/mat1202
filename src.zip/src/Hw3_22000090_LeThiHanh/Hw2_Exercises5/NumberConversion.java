package Hw3_22000090_LeThiHanh.Hw2_Exercises5;

import java.util.Scanner;

public class NumberConversion {

    // Phương thức chuyển đổi số từ hệ cơ số inRadix sang hệ cơ số outRadix
    public static String toRadix(String in, int inRadix, int outRadix) {
        // Chuyển chuỗi input thành số nguyên theo hệ cơ số inRadix
        int decimalValue = Integer.parseInt(in, inRadix);

        // Chuyển số nguyên từ hệ cơ số 10 sang hệ cơ số outRadix
        return Integer.toString(decimalValue, outRadix).toUpperCase();
    }

    // Phương thức yêu cầu người dùng nhập giá trị và hiển thị kết quả chuyển đổi
    public static void testNumberConversion() {
        Scanner scanner = new Scanner(System.in);

        // Yêu cầu người dùng nhập số và hệ cơ số đầu vào
        System.out.print("Enter a number and radix: ");
        String inputNumber = scanner.next();

        // Yêu cầu người dùng nhập hệ cơ số đầu vào
        System.out.print("Enter the input radix: ");
        int inputRadix = scanner.nextInt();

        // Yêu cầu người dùng nhập hệ cơ số đầu ra
        System.out.print("Enter the output radix: ");
        int outputRadix = scanner.nextInt();

        // Chuyển đổi số từ hệ cơ số inRadix sang hệ cơ số outRadix và hiển thị kết quả
        String result = toRadix(inputNumber, inputRadix, outputRadix);

        // In kết quả
        System.out.println("\"" + inputNumber + "\" in radix " + inputRadix + " is \"" + result + "\" in radix " + outputRadix + ".");
    }

    public static void main(String[] args) {
        testNumberConversion(); // Gọi phương thức kiểm tra chuyển đổi
    }
}
