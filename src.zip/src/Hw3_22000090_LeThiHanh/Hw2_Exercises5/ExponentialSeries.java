package Hw3_22000090_LeThiHanh.Hw2_Exercises5;

import java.util.Scanner;

public class ExponentialSeries {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        double x;
        do {
            System.out.print("Enter the x: ");
            x = sc.nextDouble();
        } while (x < -1 || x > 1);
        int num = 20;
        System.out.println(specialSeries(x,num));
    }
    public static double specialSeries(double x, int num) {
        double sum = x;
        double idx = 1;
        double temp;
        double k;
        for (double i = 2; i < num; i+=2) {
            k = (i-1) / i;
            idx *= k;
            temp = idx * Math.pow(x, i+1) / (i+1);
            sum += temp;
        }
        return sum;
    }
}
