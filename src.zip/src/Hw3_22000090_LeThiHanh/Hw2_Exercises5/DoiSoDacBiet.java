package Hw3_22000090_LeThiHanh.Hw2_Exercises5;

import java.util.Scanner;

public class DoiSoDacBiet {
    // Phương thức tính tổng dãy số đặc biệt
    public static double specialSeries(double x, int numTerms) {
        double sum = x;
        double term = 1;
        double index;
        for (double i = 1; i <= numTerms; i++) {
            term *= ((2*i-1)/(2*i));
            index = (term * Math.pow(x, 2*i+1))/(2*i+1);
            sum += index;
        }

        return sum;
    }

    public static void testSpecialSeries() {
        Scanner sc = new Scanner(System.in);
        double x;
        do {
            System.out.print("Enter the x (-1 <= x <= 1): ");
            x = sc.nextDouble();
        } while (x < -1 || x > 1);
        System.out.print("Enter the numTerms: ");
        int numTerms = sc.nextInt();
        System.out.println("Tổng của dãy số là: " + specialSeries(x, numTerms));
    }

    // Phương thức main để chạy chương trình
    public static void main(String[] args) {
        testSpecialSeries();  // Gọi phương thức kiểm tra dãy số
    }
}
