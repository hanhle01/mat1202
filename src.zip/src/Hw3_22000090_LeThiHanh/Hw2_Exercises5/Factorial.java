package Hw3_22000090_LeThiHanh.Hw2_Exercises5;

public class Factorial {

    // Phương thức tính giai thừa và xử lý tràn số cho kiểu int
    public static void factorialInt() {
        long factorial = 1;  // Giai thừa tạm thời
        for (int i = 1; i <= 12; i++) {  // Tính giai thừa từ 1 đến 12
            factorial *= i;

            // Kiểm tra xem giai thừa có thể được biểu diễn bằng int không
            if (factorial > Integer.MAX_VALUE) {
                System.out.println("The factorial of " + i + " is out of range");
            } else {
                System.out.println("The factorial of " + i + " is " + factorial);
            }
        }

        // Kiểm tra giai thừa của 13, chắc chắn sẽ vượt quá Integer.MAX_VALUE
        if (factorial > Integer.MAX_VALUE) {
            System.out.println("The factorial of 13 is out of range");
        }
    }

    // Phương thức tính giai thừa cho kiểu long (64-bit)
    public static void factorialLong() {
        long factorial = 1;  // Giai thừa tạm thời
        for (int i = 1; i <= 20; i++) {  // Tính giai thừa từ 1 đến 20
            factorial *= i;

            // Kiểm tra xem giai thừa có thể được biểu diễn bằng long không
            if (factorial > Long.MAX_VALUE) {
                System.out.println("The factorial of " + i + " is out of range");
            } else {
                System.out.println("The factorial of " + i + " is " + factorial);
            }
        }

        // Kiểm tra giai thừa của 21, chắc chắn sẽ vượt quá Long.MAX_VALUE
        if (factorial > Long.MAX_VALUE) {
            System.out.println("The factorial of 21 is out of range");
        }
    }

    public static void main(String[] args) {
        System.out.println("Factorial of int (32-bit):");
        factorialInt();  // Gọi phương thức tính giai thừa kiểu int
        System.out.println("\nFactorial of long (64-bit):");
        factorialLong();  // Gọi phương thức tính giai thừa kiểu long
    }
}
