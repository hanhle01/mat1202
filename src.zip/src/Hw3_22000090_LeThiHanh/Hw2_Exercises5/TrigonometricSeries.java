package Hw3_22000090_LeThiHanh.Hw2_Exercises5;

import java.util.Scanner;

public class TrigonometricSeries {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the x: ");
        double x = sc.nextDouble();
        System.out.print("Enter the numTerms: ");
        int num = sc.nextInt();
        System.out.println("Sin: " + sinX(x,num));
        System.out.println("Sin: " + Math.sin(x) + " (Math.sin())");
        System.out.println("Cos: " + cosX(x,num));
        System.out.println("Cos: " + Math.cos(x) + " (Math.cos())");
    }

    public static double sinX(double x, int num) {
        double result = x;
        double term;
        int idx = 1;
        for (int i = 1; i < num; i++) {
            idx*=(2*i*(2*i + 1));
            term = Math.pow(-1,i) * Math.pow(x, 2*i+1) / idx;
            result += term;
        }
        return result;
    }
    public static double cosX(double x, int num) {
        double result = 1.0;
        double term;
        int idx = 1;
        for (int i = 1; i < num; i++) {
            idx*=(2*i*(2*i - 1));
            term = Math.pow(-1,i) * Math.pow(x, 2*i) / idx;
            result += term;
        }
        return result;
    }
}
