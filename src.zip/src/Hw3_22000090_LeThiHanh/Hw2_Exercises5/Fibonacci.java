package Hw3_22000090_LeThiHanh.Hw2_Exercises5;

public class Fibonacci {

    // Phương thức tính các số Fibonacci và xử lý tràn số cho kiểu int
    public static void fibonacciInt() {
        int a = 1;  // F(0)
        int b = 1;  // F(1)
        int index = 1;  // Chỉ số hiện tại của dãy Fibonacci

        // In ra F(0)
        System.out.println("F(0) = " + a);

        // In ra F(1)
        System.out.println("F(1) = " + b);

        // Tiến hành tính dãy Fibonacci từ F(2) đến khi tràn số
        while (true) {
            // Tính F(n) = F(n-1) + F(n-2)
            int nextFib = a + b;

            // Kiểm tra xem Fibonacci tiếp theo có vượt quá Integer.MAX_VALUE không
            if (Integer.MAX_VALUE - b < a) {
                System.out.println("F(" + index + ") is out of the range of int");
                break;
            }

            // In kết quả Fibonacci
            index++;
            System.out.println("F(" + index + ") = " + nextFib);

            // Cập nhật a và b để tính Fibonacci tiếp theo
            a = b;
            b = nextFib;
        }
    }

    public static void main(String[] args) {
        fibonacciInt();  // Gọi phương thức tính số Fibonacci
    }
}
