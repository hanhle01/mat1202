package Hw3_22000090_LeThiHanh.Hw2_Exercises2;

import java.util.Scanner;

public class HillPattern {
    public static void hillPatternX(int n) {
        for (int row = 1; row <= 2*n-1; row++) {
            for (int col = 1; col < 8*n; col++) {
                if(col <= 2*n-1) {
                    if (row + col >= n + 1 && row >= col - n + 1 && row <=n) {
                        System.out.print("# ");
                    } else {
                        System.out.print("  ");
                    }
                } else if(2*n <= col && col <= 4*n-1) {
                    if (col - row >= 2*n && row + col <= 4*n && row <= n) {
                        System.out.print("# ");
                    } else {
                        System.out.print("  ");
                    }
                } else if(4*n <= col && col <= 6*n-1) {
                    if (row + col >= 5*n+1 && row + col <= 7*n-1 && col-row <= 5*n-1 && col-row >= 3*n + 1) {
                        System.out.print("# ");
                    } else {
                        System.out.print("  ");
                    }
                } else if(col >= 6*n +1) {
                    if (row + col <= 7*n+1 || row + col > 9*n-2 || col-row > 6*n+3 || col-row < 5*n+2) {
                        System.out.print("# ");
                    } else {
                        System.out.print("  ");
                    }
                } else {
                    System.out.print("  ");
                }
            }
            System.out.println();
        }
    }

    // Method to test and prompt for user input
    public static void testHillPatternX() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the rows: ");
        int n = scanner.nextInt();
        hillPatternX(n);
    }

    public static void main(String[] args) {
        // Call the test method to start the program
        testHillPatternX();
    }
}
