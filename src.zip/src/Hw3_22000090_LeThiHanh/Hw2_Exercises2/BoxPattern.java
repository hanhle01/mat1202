package Hw3_22000090_LeThiHanh.Hw2_Exercises2;

import java.util.Scanner;

public class BoxPattern {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n;
        do {
            System.out.print("Enter the size: ");
            n = sc.nextInt();
        } while (n <= 0);
        boxPattern(n);
    }

    public static void boxPattern(int n) {
        for (int i = 1; i < n; i++) {
            for (int j = 1; j < 4*n ; j++) {
                if(j==n || j==2*n || j==3*n) {
                    System.out.print("  ");
                }

                if (j<n) {
                    if (i==1 || i==n-1 || j==1 || j==n-1) {
                        System.out.print("# ");
                    } else {
                        System.out.print("  ");
                    }
                }

                if (n < j && j < 2*n) {
                    if (i==1 || i==n-1 || j-i==n) {
                        System.out.print("# ");
                    } else {
                        System.out.print("  ");
                    }
                }

                if (2*n < j && j < 3*n) {
                    if (i==1 || i==n-1 || j+i==3*n) {
                        System.out.print("# ");
                    } else {
                        System.out.print("  ");
                    }
                }

                if (3*n < j) {
                    if (i==1 || i==n-1 || j+i==4*n || j-i==3*n) {
                        System.out.print("# ");
                    } else {
                        System.out.print("  ");
                    }
                }
            }
            System.out.println();
        }
    }
}
