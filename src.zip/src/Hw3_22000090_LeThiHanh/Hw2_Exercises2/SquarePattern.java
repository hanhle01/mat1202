package Hw3_22000090_LeThiHanh.Hw2_Exercises2;

import java.util.Scanner;

public class SquarePattern {
    public static void main (String[] args) {
        Scanner sc = new Scanner(System.in);
        int n;
        do {
            System.out.print("Enter the size: ");
            n = sc.nextInt();
        } while (n <= 0);
        printSquare(n);
    }

    public static void printSquare(int n) {
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= n; j++) {
                System.out.print("# ");
            }
            System.out.println();
        }
    }
}
