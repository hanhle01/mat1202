package Hw3_22000090_LeThiHanh.Hw2_Exercises2;

import java.util.Scanner;

public class TriangularPattern {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n;
        do {
            System.out.print("Enter the size: ");
            n = sc.nextInt();
        } while (n <= 0);
        triangularPattern(n);
    }

    public static void triangularPattern(int n) {
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= 4*n+3; j++) {
                if (i >= j && j <= n) {
                    System.out.print("# ");
                } else if (j >= n+2 && i+j <= 2*n+2) {
                    System.out.print("# ");
                } else if (j >= 2*n+3 && j <= 3*n+2 && j-i >= 2*n+2) {
                    System.out.print("# ");
                } else if(i+j >= 4*n+4) {
                    System.out.print("# ");
                } else {
                    System.out.print("  ");
                }
            }
            System.out.println();
        }
    }
}
