package Hw3_22000090_LeThiHanh.Hw2_Exercises3;

import java.util.Scanner;

public class Palindromic {

    // Phương thức kiểm tra một từ có phải là palindrome không
    public static boolean isPalindromicWord(String inStr) {
        inStr = inStr.toLowerCase();  // Chuyển chuỗi về chữ thường để so sánh không phân biệt hoa thường
        int fIdx = 0;
        int bIdx = inStr.length() - 1;

        // Kiểm tra từ trái qua phải và phải qua trái
        while (fIdx < bIdx) {
            if (inStr.charAt(fIdx) != inStr.charAt(bIdx)) {
                return false; // Nếu ký tự không giống nhau, không phải palindrome
            }
            ++fIdx;
            --bIdx;
        }

        return true; // Nếu toàn bộ ký tự giống nhau, là palindrome
    }

    // Phương thức kiểm tra một cụm từ có phải là palindrome không
    public static boolean isPalindromicPhrase(String inStr) {
        inStr = inStr.toLowerCase();  // Chuyển chuỗi về chữ thường
        int fIdx = 0;
        int bIdx = inStr.length() - 1;

        // Duyệt qua cụm từ từ trái qua phải và từ phải qua trái
        while (fIdx < bIdx) {
            // Bỏ qua các ký tự không phải là chữ cái
            if (!Character.isLetter(inStr.charAt(fIdx))) {
                ++fIdx;
            } else if (!Character.isLetter(inStr.charAt(bIdx))) {
                --bIdx;
            } else {
                if (inStr.charAt(fIdx) != inStr.charAt(bIdx)) {
                    return false; // Nếu ký tự không giống nhau, không phải palindrome
                }
                ++fIdx;
                --bIdx;
            }
        }

        return true; // Nếu toàn bộ ký tự giống nhau sau khi bỏ qua dấu câu
    }

    // Phương thức yêu cầu người dùng nhập vào một từ và in ra kết quả
    public static void testPalindromicWord() {
        Scanner in = new Scanner(System.in);

        // Yêu cầu người dùng nhập vào một từ
        System.out.print("Enter a word: ");
        String word = in.nextLine();

        // Kiểm tra từ có phải là palindrome hay không và in kết quả
        if (isPalindromicWord(word)) {
            System.out.println("\"" + word + "\" is a palindrome.");
        } else {
            System.out.println("\"" + word + "\" is not a palindrome.");
        }

        in.close();
    }

    // Phương thức yêu cầu người dùng nhập vào một cụm từ và in ra kết quả
    public static void testPalindromicPhrase() {
        Scanner in = new Scanner(System.in);

        // Yêu cầu người dùng nhập vào một cụm từ
        System.out.print("Enter a phrase: ");
        String phrase = in.nextLine();

        // Kiểm tra cụm từ có phải là palindrome hay không và in kết quả
        if (isPalindromicPhrase(phrase)) {
            System.out.println("\"" + phrase + "\" is a palindrome.");
        } else {
            System.out.println("\"" + phrase + "\" is not a palindrome.");
        }

        in.close();
    }

    // Hàm main để chạy chương trình
    public static void main(String[] args) {
        testPalindromicWord();   // Kiểm tra từ palindrome
        testPalindromicPhrase(); // Kiểm tra cụm từ palindrome
    }
}
