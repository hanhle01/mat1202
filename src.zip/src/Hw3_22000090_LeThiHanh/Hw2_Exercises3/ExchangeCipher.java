package Hw3_22000090_LeThiHanh.Hw2_Exercises3;

import java.util.Scanner;

public class ExchangeCipher {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a plaintext string: ");
        String str = sc.nextLine();
        String outStr = exchangeCipher(str);
        System.out.println("The ciphered string is: " + outStr);
    }
    public static String exchangeCipher(String inStr) {
        StringBuilder outStr = new StringBuilder();
        inStr = inStr.toUpperCase();

        for (int i = 0; i < inStr.length(); i++) {
            char inChar = inStr.charAt(i);
            if (inChar >= 'A' && inChar <= 'Z') {
                char outChar = (char) ('A' + 'Z' - inChar);
                outStr.append(outChar);
            }
        }
        return outStr.toString();
    }

}
